-- ============================================================
-- CRAZY POLICE MEMBER PORTAL : ฐานข้อมูล + RLS + Storage
-- วิธีใช้: Supabase Dashboard > SQL Editor > New query > วางทั้งไฟล์ > Run
-- รันครั้งเดียวบนโปรเจกต์ใหม่ (ถ้ารันซ้ำ ส่วนใหญ่จะข้ามให้เอง)
-- ============================================================

-- ---------- ตารางรายการ ยศ / ตำแหน่ง / หน่วยงาน ----------
create table if not exists public.ranks (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  color text not null default '#7B2CBF',
  sort_order int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.positions (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  sort_order int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.departments (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  sort_order int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ---------- โปรไฟล์ผู้เล่น (สร้างอัตโนมัติเมื่อล็อกอิน Discord ครั้งแรก) ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  discord_id text,
  discord_name text not null default 'unknown',
  avatar_url text,
  roblox_name text,
  role text not null default 'member' check (role in ('member','admin','super_admin')),
  is_verified boolean not null default false,
  verified_at timestamptz,
  rank_id uuid references public.ranks(id) on delete restrict,
  position_id uuid references public.positions(id) on delete restrict,
  department_id uuid references public.departments(id) on delete restrict,
  appointed_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists profiles_discord_name_idx on public.profiles (lower(discord_name));
create index if not exists profiles_roblox_name_idx on public.profiles (lower(roblox_name));

-- ---------- คำขอยืนยันตัวตน ----------
create sequence if not exists public.verification_seq;
create table if not exists public.verification_requests (
  id uuid primary key default gen_random_uuid(),
  request_no text not null unique default ('VR-' || lpad(nextval('public.verification_seq')::text, 5, '0')),
  user_id uuid not null references auth.users(id) on delete cascade,
  discord_name text not null,
  roblox_name text not null,
  claimed_rank text not null,
  evidence_path text,
  status text not null default 'PENDING' check (status in ('PENDING','APPROVED','REJECTED')),
  reject_reason text,
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_by_name text,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);
-- หนึ่งบัญชีมีคำขอที่รอตรวจได้ครั้งละหนึ่งรายการ (กันส่งซ้ำ)
create unique index if not exists one_pending_request_per_user
  on public.verification_requests (user_id) where status = 'PENDING';

-- ---------- ประวัติการเปลี่ยนยศ ----------
create table if not exists public.rank_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  action text not null check (action in ('assign','change','promote','demote','remove','assignment')),
  old_rank_name text,
  new_rank_name text,
  old_position_name text,
  new_position_name text,
  old_department_name text,
  new_department_name text,
  reason text not null,
  changed_by uuid references auth.users(id) on delete set null,
  changed_by_name text,
  created_at timestamptz not null default now()
);
create index if not exists rank_history_user_idx on public.rank_history (user_id, created_at desc);

-- ---------- การแจ้งเตือนบนเว็บไซต์ ----------
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null default 'info',
  title text not null,
  body text,
  created_at timestamptz not null default now(),
  read_at timestamptz
);
create index if not exists notifications_user_idx on public.notifications (user_id, created_at desc);

-- ---------- กฎระเบียบ และ คู่มือใส่เสื้อเจ้าหน้าที่ (แอดมินแก้ไขได้) ----------
create table if not exists public.rules (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  title text not null,
  body text not null default '',
  sort_order int not null default 0,
  is_published boolean not null default true,
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists public.guide_items (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null default '',
  image_path text,
  sort_order int not null default 0,
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

-- ---------- ระบบร้องเรียน ----------
create sequence if not exists public.complaint_seq;
create table if not exists public.complaints (
  id uuid primary key default gen_random_uuid(),
  complaint_no text not null unique default ('CP-' || lpad(nextval('public.complaint_seq')::text, 5, '0')),
  user_id uuid not null references public.profiles(id) on delete cascade,
  subject text not null,
  accused_name text not null,
  details text not null,
  evidence_path text,
  status text not null default 'PENDING' check (status in ('PENDING','IN_REVIEW','RESOLVED','REJECTED')),
  admin_note text,
  handled_by uuid references auth.users(id) on delete set null,
  handled_by_name text,
  handled_at timestamptz,
  created_at timestamptz not null default now()
);

-- ============================================================
-- ฟังก์ชันตรวจสิทธิ์ (security definer เพื่อไม่ให้ RLS วนซ้ำ)
-- ============================================================
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role in ('admin','super_admin'));
$$;

create or replace function public.is_super_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'super_admin');
$$;

create or replace function public.is_member() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and is_verified);
$$;

-- ============================================================
-- สร้างโปรไฟล์อัตโนมัติเมื่อมีผู้ใช้ใหม่ล็อกอินด้วย Discord
-- ============================================================
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  meta jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
begin
  insert into public.profiles (id, discord_id, discord_name, avatar_url)
  values (
    new.id,
    coalesce(meta->>'provider_id', meta->>'sub'),
    coalesce(meta->'custom_claims'->>'global_name', meta->>'full_name', meta->>'name', split_part(coalesce(new.email, 'unknown'), '@', 1)),
    meta->>'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================
-- Row Level Security
-- ============================================================
alter table public.ranks                  enable row level security;
alter table public.positions              enable row level security;
alter table public.departments            enable row level security;
alter table public.profiles               enable row level security;
alter table public.verification_requests  enable row level security;
alter table public.rank_history           enable row level security;
alter table public.notifications          enable row level security;
alter table public.rules                  enable row level security;
alter table public.guide_items            enable row level security;
alter table public.complaints             enable row level security;

-- profiles: เห็นของตัวเอง หรือแอดมินเห็นทั้งหมด / ไม่มี policy แก้ไขหรือเพิ่มจากฝั่งเว็บเลย
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin());

-- รายการ ยศ/ตำแหน่ง/หน่วยงาน: ผู้ล็อกอินอ่านได้ / แก้ได้เฉพาะ Super Admin
drop policy if exists ranks_select on public.ranks;
create policy ranks_select on public.ranks for select to authenticated using (true);
drop policy if exists ranks_write on public.ranks;
create policy ranks_write on public.ranks for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());

drop policy if exists positions_select on public.positions;
create policy positions_select on public.positions for select to authenticated using (true);
drop policy if exists positions_write on public.positions;
create policy positions_write on public.positions for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());

drop policy if exists departments_select on public.departments;
create policy departments_select on public.departments for select to authenticated using (true);
drop policy if exists departments_write on public.departments;
create policy departments_write on public.departments for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());

-- คำขอยืนยันตัวตน: อ่านของตัวเองหรือแอดมิน / เขียนผ่านฟังก์ชันเท่านั้น
drop policy if exists vr_select on public.verification_requests;
create policy vr_select on public.verification_requests for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

-- ประวัติยศ: เจ้าของหรือแอดมินอ่านได้ / เขียนผ่านฟังก์ชันเท่านั้น
drop policy if exists rh_select on public.rank_history;
create policy rh_select on public.rank_history for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

-- แจ้งเตือน: อ่านของตัวเองเท่านั้น
drop policy if exists notif_select on public.notifications;
create policy notif_select on public.notifications for select to authenticated
  using (user_id = auth.uid());

-- กฎระเบียบ / คู่มือ: สมาชิกที่ยืนยันแล้วหรือแอดมินอ่านได้ / แอดมินแก้ไขได้
drop policy if exists rules_select on public.rules;
create policy rules_select on public.rules for select to authenticated
  using (public.is_admin() or (public.is_member() and is_published));
drop policy if exists rules_write on public.rules;
create policy rules_write on public.rules for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists guide_select on public.guide_items;
create policy guide_select on public.guide_items for select to authenticated
  using (public.is_admin() or public.is_member());
drop policy if exists guide_write on public.guide_items;
create policy guide_write on public.guide_items for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ร้องเรียน: เจ้าของเรื่องและแอดมินเท่านั้น / เขียนผ่านฟังก์ชันเท่านั้น
drop policy if exists complaints_select on public.complaints;
create policy complaints_select on public.complaints for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

-- ปิดสิทธิ์ของ anon ทั้งหมด (ต้องล็อกอินก่อนเสมอ)
revoke all on all tables in schema public from anon;
revoke all on all sequences in schema public from anon;

-- ============================================================
-- ฟังก์ชันที่ผู้ใช้เรียกจากหน้าเว็บ (ตรวจสิทธิ์ที่ฝั่งฐานข้อมูลทุกครั้ง)
-- ============================================================

-- ส่งคำขอยืนยันตัวตน (ชื่อ Discord ดึงจากบัญชีที่ล็อกอิน ไม่รับจากฟอร์ม)
create or replace function public.submit_verification(p_roblox_name text, p_claimed_rank text, p_evidence_path text)
returns public.verification_requests
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles;
  r public.verification_requests;
begin
  select * into me from public.profiles where id = auth.uid();
  if me.id is null then raise exception 'ไม่พบบัญชีผู้ใช้'; end if;
  if me.is_verified then raise exception 'บัญชีนี้ยืนยันตัวตนแล้ว'; end if;
  if coalesce(trim(p_roblox_name), '') = '' then raise exception 'กรุณากรอกชื่อ Roblox'; end if;
  if char_length(p_roblox_name) > 40 then raise exception 'ชื่อ Roblox ยาวเกินไป'; end if;
  if coalesce(trim(p_claimed_rank), '') = '' then raise exception 'กรุณาระบุยศหรือตำแหน่ง'; end if;
  if char_length(p_claimed_rank) > 80 then raise exception 'ยศ/ตำแหน่งยาวเกินไป'; end if;
  if trim(p_claimed_rank) <> 'ยศประชาชน' and coalesce(p_evidence_path, '') = '' then
    raise exception 'กรุณาแนบรูปหลักฐานยศหรือตำแหน่ง';
  end if;
  if p_evidence_path is not null and p_evidence_path <> '' and left(p_evidence_path, 37) <> (auth.uid()::text || '/') then
    raise exception 'ไฟล์หลักฐานไม่ถูกต้อง';
  end if;
  if exists (select 1 from public.verification_requests where user_id = auth.uid() and status = 'PENDING') then
    raise exception 'มีคำขอที่รอตรวจสอบอยู่แล้ว';
  end if;

  insert into public.verification_requests (user_id, discord_name, roblox_name, claimed_rank, evidence_path)
  values (auth.uid(), me.discord_name, trim(p_roblox_name), trim(p_claimed_rank), nullif(p_evidence_path, ''))
  returning * into r;
  return r;
end;
$$;

-- แอดมินอนุมัติ / ปฏิเสธคำขอยืนยันตัวตน
create or replace function public.review_verification(p_request uuid, p_approve boolean, p_reason text default null)
returns public.verification_requests
language plpgsql security definer set search_path = public as $$
declare
  admin_row public.profiles;
  r public.verification_requests;
begin
  if not public.is_admin() then raise exception 'ไม่มีสิทธิ์ดำเนินการ'; end if;
  select * into admin_row from public.profiles where id = auth.uid();
  select * into r from public.verification_requests where id = p_request for update;
  if r.id is null then raise exception 'ไม่พบคำขอ'; end if;
  if r.status <> 'PENDING' then raise exception 'คำขอนี้ถูกตรวจสอบไปแล้ว'; end if;

  if p_approve then
    update public.verification_requests
      set status = 'APPROVED', reviewed_by = auth.uid(), reviewed_by_name = admin_row.discord_name, reviewed_at = now(), reject_reason = null
      where id = p_request returning * into r;
    update public.profiles
      set is_verified = true, verified_at = now(), roblox_name = r.roblox_name
      where id = r.user_id;
    insert into public.notifications (user_id, kind, title, body)
      values (r.user_id, 'verification_approved', 'ยืนยันตัวตนสำเร็จ', 'คำขอ ' || r.request_no || ' ได้รับการอนุมัติแล้ว เข้าสู่หน้าสมาชิกได้ทันที');
  else
    if coalesce(trim(p_reason), '') = '' then raise exception 'กรุณาระบุเหตุผลที่ปฏิเสธ'; end if;
    update public.verification_requests
      set status = 'REJECTED', reviewed_by = auth.uid(), reviewed_by_name = admin_row.discord_name, reviewed_at = now(), reject_reason = trim(p_reason)
      where id = p_request returning * into r;
    insert into public.notifications (user_id, kind, title, body)
      values (r.user_id, 'verification_rejected', 'คำขอยืนยันตัวตนถูกปฏิเสธ', 'คำขอ ' || r.request_no || ' ถูกปฏิเสธ เหตุผล: ' || trim(p_reason));
  end if;
  return r;
end;
$$;

-- แอดมินเพิ่ม/เปลี่ยน/เลื่อน/ลด/ถอดยศ และกำหนดตำแหน่ง/หน่วยงาน
create or replace function public.set_member_assignment(
  p_user uuid, p_action text, p_rank uuid, p_position uuid, p_department uuid, p_reason text
) returns public.profiles
language plpgsql security definer set search_path = public as $$
declare
  admin_row public.profiles;
  target public.profiles;
  old_rank text; new_rank text;
  old_pos text; new_pos text;
  old_dep text; new_dep text;
begin
  if not public.is_admin() then raise exception 'ไม่มีสิทธิ์ดำเนินการ'; end if;
  if p_action not in ('assign','change','promote','demote','remove','assignment') then raise exception 'การดำเนินการไม่ถูกต้อง'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'กรุณาระบุเหตุผล'; end if;

  select * into admin_row from public.profiles where id = auth.uid();
  select * into target from public.profiles where id = p_user for update;
  if target.id is null then raise exception 'ไม่พบผู้เล่น'; end if;
  if not target.is_verified then raise exception 'ผู้เล่นยังไม่ผ่านการยืนยันตัวตน'; end if;
  if target.id = auth.uid() and admin_row.role <> 'super_admin' then
    raise exception 'ไม่สามารถเปลี่ยนยศของตนเองได้';
  end if;
  if p_action = 'remove' then p_rank := null; end if;

  select name into old_rank from public.ranks where id = target.rank_id;
  select name into old_pos from public.positions where id = target.position_id;
  select name into old_dep from public.departments where id = target.department_id;
  select name into new_rank from public.ranks where id = p_rank;
  select name into new_pos from public.positions where id = p_position;
  select name into new_dep from public.departments where id = p_department;

  if p_rank is not null and new_rank is null then raise exception 'ไม่พบยศที่เลือก'; end if;
  if p_position is not null and new_pos is null then raise exception 'ไม่พบตำแหน่งที่เลือก'; end if;
  if p_department is not null and new_dep is null then raise exception 'ไม่พบหน่วยงานที่เลือก'; end if;
  if p_rank is not distinct from target.rank_id
     and p_position is not distinct from target.position_id
     and p_department is not distinct from target.department_id then
    raise exception 'ไม่มีการเปลี่ยนแปลง';
  end if;

  update public.profiles
    set rank_id = p_rank, position_id = p_position, department_id = p_department,
        appointed_at = case when p_rank is not null and p_rank is distinct from target.rank_id then now()
                            when p_rank is null then null
                            else target.appointed_at end
    where id = p_user returning * into target;

  insert into public.rank_history (user_id, action, old_rank_name, new_rank_name, old_position_name, new_position_name,
                                   old_department_name, new_department_name, reason, changed_by, changed_by_name)
  values (p_user, p_action, old_rank, new_rank, old_pos, new_pos, old_dep, new_dep, trim(p_reason), auth.uid(), admin_row.discord_name);

  insert into public.notifications (user_id, kind, title, body)
  values (p_user, 'rank_changed', 'ข้อมูลยศ/ตำแหน่งของคุณถูกอัปเดต',
          'ยศ: ' || coalesce(old_rank, 'ประชาชน') || ' → ' || coalesce(new_rank, 'ประชาชน') ||
          ' | ตำแหน่ง: ' || coalesce(new_pos, 'ยังไม่ได้รับการแต่งตั้ง') ||
          ' | หน่วยงาน: ' || coalesce(new_dep, 'ยังไม่ได้สังกัด') ||
          ' | เหตุผล: ' || trim(p_reason));
  return target;
end;
$$;

-- Super Admin กำหนดสิทธิ์ผู้ดูแลระบบ
create or replace function public.set_user_role(p_user uuid, p_role text) returns public.profiles
language plpgsql security definer set search_path = public as $$
declare t public.profiles;
begin
  if not public.is_super_admin() then raise exception 'เฉพาะ Super Admin เท่านั้น'; end if;
  if p_role not in ('member','admin','super_admin') then raise exception 'สิทธิ์ไม่ถูกต้อง'; end if;
  if p_user = auth.uid() then raise exception 'ไม่สามารถเปลี่ยนสิทธิ์ของตนเองได้'; end if;
  update public.profiles set role = p_role where id = p_user returning * into t;
  if t.id is null then raise exception 'ไม่พบผู้ใช้'; end if;
  return t;
end;
$$;

-- ส่งเรื่องร้องเรียน (เฉพาะสมาชิกที่ยืนยันแล้ว)
create or replace function public.submit_complaint(p_subject text, p_accused text, p_details text, p_evidence_path text)
returns public.complaints
language plpgsql security definer set search_path = public as $$
declare c public.complaints;
begin
  if not public.is_member() then raise exception 'ต้องยืนยันตัวตนก่อนจึงจะร้องเรียนได้'; end if;
  if coalesce(trim(p_subject), '') = '' or coalesce(trim(p_accused), '') = '' or coalesce(trim(p_details), '') = '' then
    raise exception 'กรุณากรอกข้อมูลให้ครบ';
  end if;
  if char_length(p_details) > 4000 then raise exception 'รายละเอียดยาวเกินไป'; end if;
  if p_evidence_path is not null and p_evidence_path <> '' and left(p_evidence_path, 37) <> (auth.uid()::text || '/') then
    raise exception 'ไฟล์หลักฐานไม่ถูกต้อง';
  end if;
  insert into public.complaints (user_id, subject, accused_name, details, evidence_path)
  values (auth.uid(), trim(p_subject), trim(p_accused), trim(p_details), nullif(p_evidence_path, ''))
  returning * into c;
  return c;
end;
$$;

-- แอดมินอัปเดตสถานะเรื่องร้องเรียน
create or replace function public.update_complaint(p_id uuid, p_status text, p_note text default null)
returns public.complaints
language plpgsql security definer set search_path = public as $$
declare c public.complaints; admin_row public.profiles;
begin
  if not public.is_admin() then raise exception 'ไม่มีสิทธิ์ดำเนินการ'; end if;
  if p_status not in ('PENDING','IN_REVIEW','RESOLVED','REJECTED') then raise exception 'สถานะไม่ถูกต้อง'; end if;
  select * into admin_row from public.profiles where id = auth.uid();
  update public.complaints
    set status = p_status, admin_note = nullif(trim(coalesce(p_note, '')), ''),
        handled_by = auth.uid(), handled_by_name = admin_row.discord_name, handled_at = now()
    where id = p_id returning * into c;
  if c.id is null then raise exception 'ไม่พบเรื่องร้องเรียน'; end if;
  insert into public.notifications (user_id, kind, title, body)
  values (c.user_id, 'complaint_updated', 'เรื่องร้องเรียน ' || c.complaint_no || ' อัปเดตสถานะ',
          'สถานะใหม่: ' || p_status || coalesce(' | หมายเหตุ: ' || c.admin_note, ''));
  return c;
end;
$$;

-- ทำเครื่องหมายอ่านแจ้งเตือนทั้งหมดของตนเอง
create or replace function public.mark_notifications_read() returns void
language sql security definer set search_path = public as $$
  update public.notifications set read_at = now() where user_id = auth.uid() and read_at is null;
$$;

-- อนุญาตให้เรียกฟังก์ชันได้เฉพาะผู้ล็อกอิน
revoke execute on all functions in schema public from public, anon;
grant execute on function
  public.is_admin(), public.is_super_admin(), public.is_member(),
  public.submit_verification(text, text, text),
  public.review_verification(uuid, boolean, text),
  public.set_member_assignment(uuid, text, uuid, uuid, uuid, text),
  public.set_user_role(uuid, text),
  public.submit_complaint(text, text, text, text),
  public.update_complaint(uuid, text, text),
  public.mark_notifications_read()
to authenticated;

grant usage on schema public to authenticated;
grant select on all tables in schema public to authenticated;
grant insert, update, delete on public.ranks, public.positions, public.departments, public.rules, public.guide_items to authenticated;
grant usage, select on all sequences in schema public to authenticated;

-- ============================================================
-- Realtime (แจ้งเตือนทันทีบนเว็บ)
-- ============================================================
do $$ begin
  alter publication supabase_realtime add table public.notifications;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.verification_requests;
exception when duplicate_object then null; end $$;

-- ============================================================
-- Storage: ถังเก็บรูป (ส่วนตัวทั้งหมด เข้าถึงผ่าน signed URL เท่านั้น)
-- evidence = รูปหลักฐานยืนยันตัวตน/ร้องเรียน (โฟลเดอร์ละ 1 ผู้ใช้)
-- guide    = รูปประกอบคู่มือใส่เสื้อเจ้าหน้าที่
-- ============================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('evidence', 'evidence', false, 5242880, array['image/png','image/jpeg','image/webp']),
  ('guide',    'guide',    false, 5242880, array['image/png','image/jpeg','image/webp'])
on conflict (id) do update
  set public = false, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists evidence_insert on storage.objects;
create policy evidence_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'evidence' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists evidence_select on storage.objects;
create policy evidence_select on storage.objects for select to authenticated
  using (bucket_id = 'evidence' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

drop policy if exists guide_obj_select on storage.objects;
create policy guide_obj_select on storage.objects for select to authenticated
  using (bucket_id = 'guide' and (public.is_admin() or public.is_member()));

drop policy if exists guide_obj_insert on storage.objects;
create policy guide_obj_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'guide' and public.is_admin());

drop policy if exists guide_obj_delete on storage.objects;
create policy guide_obj_delete on storage.objects for delete to authenticated
  using (bucket_id = 'guide' and public.is_admin());

-- ============================================================
-- ข้อมูลเริ่มต้น (แก้ไข/ลบ/เพิ่มได้ในหน้า RANK MANAGEMENT ภายหลัง)
-- ============================================================
insert into public.ranks (name, color, sort_order) values
  ('พลตำรวจเอก',      '#FACC15', 10),
  ('พลตำรวจโท',       '#FACC15', 20),
  ('พลตำรวจตรี',      '#FACC15', 30),
  ('พันตำรวจเอก',     '#39FF88', 40),
  ('พันตำรวจโท',      '#39FF88', 50),
  ('พันตำรวจตรี',     '#39FF88', 60),
  ('ร้อยตำรวจเอก',    '#7B2CBF', 70),
  ('ร้อยตำรวจโท',     '#7B2CBF', 80),
  ('ร้อยตำรวจตรี',    '#7B2CBF', 90),
  ('ดาบตำรวจ',        '#A78BFA', 100),
  ('จ่าสิบตำรวจ',     '#A78BFA', 110),
  ('สิบตำรวจเอก',     '#94A3B8', 120),
  ('สิบตำรวจโท',      '#94A3B8', 130),
  ('สิบตำรวจตรี',     '#94A3B8', 140),
  ('พลตำรวจ',         '#94A3B8', 150)
on conflict (name) do nothing;

-- ============================================================
-- ตั้ง Super Admin คนแรก (ทำหลังจากล็อกอินด้วย Discord บนเว็บไซต์ 1 ครั้ง)
-- แก้ 'ชื่อ Discord ของคุณ' แล้วรันบรรทัดนี้แยกต่างหาก:
--
--   update public.profiles set role = 'super_admin', is_verified = true, verified_at = now()
--   where discord_name = 'ชื่อ Discord ของคุณ';
-- ============================================================
