/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#100D18',
        panel: '#1C1726',
        panel2: '#251E33',
        line: '#2F2742',
        royal: '#7B2CBF',
        neon: '#39FF88',
        mute: '#A79FBA',
      },
      fontFamily: {
        display: ['"Chakra Petch"', '"IBM Plex Sans Thai"', 'sans-serif'],
        sans: ['"IBM Plex Sans Thai"', '"Chakra Petch"', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
    },
  },
  plugins: [],
};
