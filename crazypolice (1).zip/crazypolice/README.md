# CRAZY POLICE MEMBER PORTAL

เว็บศูนย์กลางสมาชิกแมพ Roblox Roleplay ตำรวจ **CRAZY POLICE**
ลิงก์เดียวนำไปโพสต์ใน Discord ได้ สมาชิกกดแล้วล็อกอินด้วย Discord และยืนยันตัวตนผ่านเว็บได้ทันที (ไม่ใช้ Discord Bot)

เทคโนโลยี: React + TypeScript + Tailwind CSS + Supabase (Auth, PostgreSQL, Storage, Realtime)

## ระบบที่มี

| ส่วน | รายละเอียด |
|---|---|
| ล็อกอิน | Discord OAuth ผ่าน Supabase Auth (ระบุตัวตนจากบัญชีจริง ไม่ใช่ชื่อที่พิมพ์เอง) |
| ยืนยันตัวตน | ฟอร์ม + อัปโหลดรูปหลักฐาน (PNG/JPG/WEBP ≤5MB) พร้อมตัวอย่าง เปลี่ยน/ลบรูปได้ สร้างเลข `VR-00001` สถานะ PENDING |
| แอดมิน | แดชบอร์ด สถิติ ตารางคำขอ ดูหลักฐาน อนุมัติ/ปฏิเสธ (ต้องใส่เหตุผล) บันทึกผู้ตรวจและเวลา |
| แจ้งเตือน | ตาราง `notifications` + Realtime ผู้เล่นเห็นผลทันที และเห็นสถานะล่าสุดจากฐานข้อมูลเมื่อกลับมาเปิดใหม่ |
| หน้าสมาชิก | หน้าแรก, กฎระเบียบ, คู่มือใส่เสื้อเจ้าหน้าที่, ระบบร้องเรียน, ข้อมูลสมาชิก (บัตร + ประวัติยศ) |
| ยศ/ตำแหน่ง | เพิ่ม/เปลี่ยน/เลื่อน/ลด/ถอดยศ กำหนดตำแหน่งและหน่วยงาน ค้นหาผู้เล่น ดูประวัติย้อนหลัง ต้องใส่เหตุผลทุกครั้ง |
| RANK MANAGEMENT | (Super Admin) เพิ่ม/แก้ชื่อ/ลบ/จัดลำดับ/เปิด-ปิด/กำหนดสีของยศ และจัดการรายการตำแหน่ง หน่วยงาน ลบไม่ได้ถ้ายังมีผู้ใช้ |
| กฎ/คู่มือ | แอดมินเพิ่ม แก้ไข ลบ ได้จากหน้าเว็บ ถ้ายังไม่มีข้อมูลจะแสดงว่า "ยังไม่มี" ไม่มีลิงก์หรือรูปปลอม |

ความปลอดภัยอยู่ที่ฐานข้อมูล: ทุกตารางเปิด Row Level Security การเปลี่ยนสถานะ ยศ และสิทธิ์ทำผ่านฟังก์ชันใน `supabase/schema.sql` ที่ตรวจสิทธิ์แอดมินจากฐานข้อมูลทุกครั้ง สมาชิกทั่วไปแก้ URL หรือยิง API เองก็เปลี่ยนยศตนเองไม่ได้ รูปทั้งหมดอยู่ใน bucket ส่วนตัวและเปิดผ่านลิงก์ชั่วคราวเท่านั้น

---

## ติดตั้งและเผยแพร่ (ใช้ Free Tier ทั้งหมด)

### 1) สร้างฐานข้อมูล Supabase
1. สมัคร/เข้า https://supabase.com แล้วกด **New project** (ตั้งรหัสผ่านฐานข้อมูลเก็บไว้เอง)
2. เมนู **SQL Editor → New query** วางเนื้อหาไฟล์ `supabase/schema.sql` ทั้งไฟล์ แล้วกด **Run**
3. เมนู **Project Settings → API** คัดลอก 2 ค่า
   - `Project URL`
   - `anon public` key
   > ใช้เฉพาะ anon key เท่านั้น **ห้ามนำ service_role key ไปใส่ในเว็บหรือ GitHub**

### 2) ตั้งค่า Discord Login
1. เข้า https://discord.com/developers/applications → **New Application** (ตั้งชื่อ CRAZY POLICE) *(ไม่ต้องสร้าง Bot)*
2. เมนู **OAuth2** คัดลอก **Client ID** และกด Reset Secret เพื่อรับ **Client Secret**
3. ในหน้าเดียวกัน **Redirects → Add Redirect** ใส่
   `https://<รหัสโปรเจกต์>.supabase.co/auth/v1/callback`
   (ดูค่านี้ได้ใน Supabase: **Authentication → Providers → Discord** ช่อง Callback URL)
4. กลับ Supabase: **Authentication → Providers → Discord** เปิดใช้งาน ใส่ Client ID / Client Secret แล้ว Save

### 3) เผยแพร่เว็บ (ตัวอย่าง Vercel)
1. อัปโหลดโฟลเดอร์โปรเจกต์นี้ขึ้น GitHub (ไฟล์ `.env` ถูก ignore ไว้แล้ว ไม่หลุดขึ้น repo)
2. เข้า https://vercel.com → **Add New → Project** → เลือก repo
3. Framework เลือก **Vite** (Build `npm run build`, Output `dist`)
4. ที่ **Environment Variables** เพิ่ม
   - `VITE_SUPABASE_URL` = Project URL
   - `VITE_SUPABASE_ANON_KEY` = anon public key
5. กด **Deploy** จะได้ลิงก์ เช่น `https://crazypolice.vercel.app`

> ใช้ Netlify หรือ Cloudflare Pages แทนได้ ตั้งค่าเหมือนกัน (มีไฟล์ rewrite ให้แล้ว: `vercel.json`, `public/_redirects`)

### 4) บอก Supabase ว่าเว็บอยู่ที่ไหน
Supabase: **Authentication → URL Configuration**
- **Site URL** = ลิงก์เว็บของคุณ (เช่น `https://crazypolice.vercel.app`)
- **Redirect URLs** เพิ่ม `https://crazypolice.vercel.app/**` (และ `http://localhost:5173/**` ถ้าจะทดสอบในเครื่อง)

### 5) ตั้งตัวเองเป็น Super Admin
1. เปิดเว็บ กด **ยืนยันตัวตน** → ล็อกอินด้วย Discord หนึ่งครั้ง
2. Supabase **SQL Editor** รัน (แก้ชื่อให้ตรงกับชื่อ Discord ที่แสดงบนเว็บ)

```sql
update public.profiles
set role = 'super_admin', is_verified = true, verified_at = now()
where discord_name = 'ชื่อ Discord ของคุณ';
```

3. รีเฟรชเว็บ จะเห็นปุ่ม **หลังบ้านแอดมิน**

### 6) ลิงก์ที่ได้
- ลิงก์สมาชิก (โพสต์ใน Discord): `https://<โดเมนของคุณ>/`
- ลิงก์แอดมิน: `https://<โดเมนของคุณ>/admin` (เข้าได้เฉพาะ role admin / super_admin ตรวจที่ฐานข้อมูล)

### 7) เริ่มใช้งานจริง
1. Super Admin เข้า **RANK MANAGEMENT** ปรับรายการยศ (ระบบใส่ยศตำรวจเริ่มต้นไว้ให้แก้ได้) เพิ่มตำแหน่งและหน่วยงาน
2. เข้า **กฎและคู่มือ** เพิ่มกฎของแมพและขั้นตอนใส่เสื้อเจ้าหน้าที่พร้อมรูป
3. ตั้งแอดมินคนอื่น: หน้า **สมาชิกและยศ** (Super Admin เห็นช่องเลือกสิทธิ์ใต้การ์ดสมาชิก)

## รันในเครื่อง
```bash
npm install
cp .env.example .env   # ใส่ค่า Supabase
npm run dev
```

## หมายเหตุ
- ผู้ใช้ที่ยังไม่ยืนยันตัวตนเข้าได้เฉพาะหน้าแรกและหน้ายืนยันตัวตน กฎ/คู่มือถูกกั้นด้วย RLS ที่ฐานข้อมูล ไม่ใช่แค่ซ่อนปุ่ม
- ชื่อ Discord ในคำขอดึงจากบัญชีที่ล็อกอิน ไม่ใช่ช่องที่พิมพ์เอง
- ผู้ถูกปฏิเสธส่งคำขอใหม่ได้ ตราบใดที่ไม่มีคำขอที่รอตรวจอยู่ (ระบบกันส่งซ้ำด้วย unique index)
- ไม่มีระบบอีเมลหรือ Discord Bot แจ้งเตือน การแจ้งเตือนทั้งหมดอยู่บนเว็บไซต์
