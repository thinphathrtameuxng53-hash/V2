import { ShieldLogo } from '../components/ui';

/** แสดงเมื่อยังไม่ได้ตั้งค่า Supabase ตรง ๆ ไม่แกล้งทำเป็นเชื่อมต่อแล้ว */
export default function Setup() {
  return (
    <div className="mx-auto flex min-h-screen max-w-xl flex-col justify-center gap-5 px-4 py-10">
      <ShieldLogo size={56} />
      <h1 className="h-display text-3xl">ยังไม่ได้เชื่อมต่อฐานข้อมูล</h1>
      <p className="text-mute">
        เว็บไซต์ถูกติดตั้งแล้ว แต่ยังไม่พบค่า <code className="font-mono text-neon">VITE_SUPABASE_URL</code> และ{' '}
        <code className="font-mono text-neon">VITE_SUPABASE_ANON_KEY</code> ระบบยืนยันตัวตนและฐานข้อมูลจึงยังใช้งานไม่ได้
      </p>
      <ol className="list-decimal space-y-1 pl-5 text-sm text-mute">
        <li>สร้างโปรเจกต์ที่ supabase.com แล้วรันไฟล์ supabase/schema.sql</li>
        <li>คัดลอก Project URL และ anon key ไปใส่ใน .env (หรือ Environment Variables ของผู้ให้บริการโฮสต์)</li>
        <li>Build / Deploy ใหม่อีกครั้ง</li>
      </ol>
      <p className="text-sm text-mute">รายละเอียดทีละขั้นตอนอยู่ในไฟล์ README.md</p>
    </div>
  );
}
