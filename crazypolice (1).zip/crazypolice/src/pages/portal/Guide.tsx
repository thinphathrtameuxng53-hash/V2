import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import type { GuideItem } from '../../lib/types';
import { Empty, ErrorBox, PageTitle, SignedImage, Spinner } from '../../components/ui';

export default function Guide() {
  const [items, setItems] = useState<GuideItem[] | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    supabase
      .from('guide_items')
      .select('*')
      .order('sort_order')
      .order('created_at')
      .then(({ data, error }) => {
        if (error) setErr(error.message);
        setItems((data ?? []) as GuideItem[]);
      });
  }, []);

  if (!items) return <Spinner />;
  return (
    <div>
      <PageTitle eyebrow="UNIFORM GUIDE" title="วิธีใส่เสื้อเจ้าหน้าที่" />
      <ErrorBox message={err} />
      {items.length === 0 ? (
        <Empty title="ยังไม่มีคู่มือ" hint="ทีมงานยังไม่ได้เพิ่มคู่มือการใส่ชุดเจ้าหน้าที่ เมื่อเพิ่มแล้วจะแสดงที่หน้านี้" />
      ) : (
        <ol className="space-y-5">
          {items.map((g, i) => (
            <li key={g.id} className="card rise">
              <p className="eyebrow">STEP {String(i + 1).padStart(2, '0')}</p>
              <h2 className="h-display mb-2 text-xl">{g.title}</h2>
              {g.body && <p className="mb-3 whitespace-pre-wrap break-words text-mute">{g.body}</p>}
              {g.image_path && <SignedImage bucket="guide" path={g.image_path} alt={g.title} />}
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}
