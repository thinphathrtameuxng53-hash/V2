import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { useAuth } from '../../lib/auth';
import { supabase, uploadImage } from '../../lib/supabase';
import { fmtDate, type Complaint } from '../../lib/types';
import { Empty, ErrorBox, ImagePicker, Modal, OkBox, PageTitle, SignedImage, Spinner, StatusChip } from '../../components/ui';

export default function Complaints() {
  const { user } = useAuth();
  const [list, setList] = useState<Complaint[] | null>(null);
  const [subject, setSubject] = useState('');
  const [accused, setAccused] = useState('');
  const [details, setDetails] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [view, setView] = useState<Complaint | null>(null);

  const load = useCallback(async () => {
    if (!user) return;
    const { data, error } = await supabase.from('complaints').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
    if (error) setErr(error.message);
    setList((data ?? []) as Complaint[]);
  }, [user?.id]);

  useEffect(() => {
    load();
    if (!user) return;
    const ch = supabase
      .channel('cmp-' + user.id)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'complaints', filter: `user_id=eq.${user.id}` }, () => load())
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [user?.id]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setErr(null);
    setOk(null);
    if (!subject.trim() || !accused.trim() || !details.trim()) return setErr('กรุณากรอกหัวข้อ ชื่อผู้ถูกร้องเรียน และรายละเอียดให้ครบ');
    setBusy(true);
    try {
      let path = '';
      if (file) path = await uploadImage('evidence', user!.id, file);
      const { data, error } = await supabase.rpc('submit_complaint', {
        p_subject: subject,
        p_accused: accused,
        p_details: details,
        p_evidence_path: path,
      });
      if (error) throw new Error(error.message);
      const row = data as Complaint;
      if (!row?.complaint_no) throw new Error('ระบบไม่ได้ยืนยันการบันทึกข้อมูล กรุณาลองใหม่');
      setOk(`ส่งเรื่องร้องเรียนสำเร็จ หมายเลข ${row.complaint_no} สถานะ PENDING`);
      setSubject('');
      setAccused('');
      setDetails('');
      setFile(null);
      await load();
    } catch (ex: any) {
      setErr(ex.message ?? 'ส่งเรื่องไม่สำเร็จ');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-8">
      <PageTitle eyebrow="COMPLAINT SYSTEM" title="ระบบร้องเรียน" />

      <form onSubmit={submit} className="card space-y-4" noValidate>
        <h2 className="h-display text-xl">ส่งเรื่องร้องเรียนใหม่</h2>
        <p className="text-sm text-mute">ข้อมูลเป็นส่วนตัว เฉพาะคุณและแอดมินที่ได้รับอนุญาตเท่านั้นที่เปิดดูได้</p>
        <div>
          <label className="label" htmlFor="subject">
            หัวข้อร้องเรียน <span className="text-neon">*</span>
          </label>
          <input id="subject" className="input" value={subject} onChange={(e) => setSubject(e.target.value)} maxLength={120} />
        </div>
        <div>
          <label className="label" htmlFor="accused">
            ชื่อผู้ถูกร้องเรียน <span className="text-neon">*</span>
          </label>
          <input id="accused" className="input" value={accused} onChange={(e) => setAccused(e.target.value)} maxLength={80} placeholder="ชื่อ Roblox หรือ Discord" />
        </div>
        <div>
          <label className="label" htmlFor="details">
            รายละเอียด <span className="text-neon">*</span>
          </label>
          <textarea id="details" className="input min-h-32" value={details} onChange={(e) => setDetails(e.target.value)} maxLength={4000} />
        </div>
        <ImagePicker file={file} onChange={setFile} label="รูปหลักฐานประกอบ (ถ้ามี)" />
        <ErrorBox message={err} />
        <OkBox message={ok} />
        <button type="submit" className="btn-primary" disabled={busy}>
          {busy ? 'กำลังส่ง...' : 'ส่งเรื่องร้องเรียน'}
        </button>
      </form>

      <section>
        <h2 className="h-display mb-3 text-xl">เรื่องร้องเรียนของฉัน</h2>
        {!list ? (
          <Spinner />
        ) : list.length === 0 ? (
          <Empty title="ยังไม่มีเรื่องร้องเรียน" />
        ) : (
          <div className="space-y-2">
            {list.map((c) => (
              <button key={c.id} onClick={() => setView(c)} className="card-plain flex w-full flex-wrap items-center justify-between gap-2 text-left transition hover:border-neon">
                <span className="min-w-0">
                  <span className="block font-mono text-xs text-neon">{c.complaint_no}</span>
                  <span className="block truncate font-display font-semibold">{c.subject}</span>
                  <span className="block font-mono text-xs text-mute">{fmtDate(c.created_at)}</span>
                </span>
                <StatusChip status={c.status} />
              </button>
            ))}
          </div>
        )}
      </section>

      {view && (
        <Modal title={view.complaint_no} onClose={() => setView(null)}>
          <div className="space-y-3 text-sm">
            <StatusChip status={view.status} />
            <p className="font-display text-lg font-semibold">{view.subject}</p>
            <p>
              <span className="text-mute">ผู้ถูกร้องเรียน: </span>
              {view.accused_name}
            </p>
            <p className="whitespace-pre-wrap break-words">{view.details}</p>
            {view.evidence_path && <SignedImage bucket="evidence" path={view.evidence_path} alt="หลักฐาน" />}
            {view.admin_note && (
              <div className="border border-line bg-ink p-3">
                <p className="font-mono text-xs text-mute">หมายเหตุจากทีมงาน • {view.handled_by_name ?? '-'} • {fmtDate(view.handled_at)}</p>
                <p className="mt-1 whitespace-pre-wrap break-words">{view.admin_note}</p>
              </div>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
}
