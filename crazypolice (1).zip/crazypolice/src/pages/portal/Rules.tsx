import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { RULE_CATEGORIES, type Rule } from '../../lib/types';
import { Empty, ErrorBox, PageTitle, Spinner } from '../../components/ui';

export default function Rules() {
  const [rules, setRules] = useState<Rule[] | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    supabase
      .from('rules')
      .select('*')
      .eq('is_published', true)
      .order('sort_order')
      .order('created_at')
      .then(({ data, error }) => {
        if (error) setErr(error.message);
        setRules((data ?? []) as Rule[]);
      });
  }, []);

  if (!rules) return <Spinner />;

  const cats: string[] = Array.from(new Set<string>(rules.map((r) => r.category)));
  cats.sort((a, b) => {
    const ia = RULE_CATEGORIES.indexOf(a);
    const ib = RULE_CATEGORIES.indexOf(b);
    return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
  });

  return (
    <div>
      <PageTitle eyebrow="RULES & REGULATIONS" title="กฎระเบียบแมพ CRAZY POLICE" />
      <ErrorBox message={err} />
      {rules.length === 0 ? (
        <Empty title="ยังไม่มีกฎระเบียบ" hint="ทีมงานยังไม่ได้เพิ่มกฎ เมื่อเพิ่มแล้วจะแสดงที่หน้านี้" />
      ) : (
        <div className="space-y-8">
          {cats.map((c) => (
            <section key={c} className="rise">
              <h2 className="h-display mb-3 border-l-4 border-royal pl-3 text-xl">{c}</h2>
              <div className="space-y-2">
                {rules
                  .filter((r) => r.category === c)
                  .map((r) => (
                    <details key={r.id} className="card-plain group" open>
                      <summary className="cursor-pointer font-display font-semibold marker:text-neon">{r.title}</summary>
                      <p className="mt-2 whitespace-pre-wrap break-words text-mute">{r.body}</p>
                    </details>
                  ))}
              </div>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}
