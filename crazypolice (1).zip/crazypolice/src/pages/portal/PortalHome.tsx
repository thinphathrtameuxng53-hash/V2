import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../lib/auth';
import { supabase } from '../../lib/supabase';
import { fmtDate, type Notice } from '../../lib/types';
import { Empty, PageTitle, RankChip } from '../../components/ui';

const LINKS = [
  { to: '/portal/rules', t: 'กฎระเบียบแมพ', d: 'กฎทั่วไปและข้อห้ามทั้งหมด' },
  { to: '/portal/guide', t: 'วิธีใส่เสื้อเจ้าหน้าที่', d: 'คู่มือแต่งตัวตามยศ' },
  { to: '/portal/complaints', t: 'ระบบร้องเรียน', d: 'ส่งเรื่องและติดตามสถานะ' },
  { to: '/portal/profile', t: 'ข้อมูลสมาชิก', d: 'ยศ ตำแหน่ง และประวัติ' },
];

export default function PortalHome() {
  const { profile } = useAuth();
  const [items, setItems] = useState<Notice[]>([]);

  useEffect(() => {
    supabase
      .from('notifications')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(5)
      .then(({ data }) => setItems((data ?? []) as Notice[]));
  }, []);

  if (!profile) return null;
  return (
    <div className="space-y-8">
      <PageTitle eyebrow="MEMBER PORTAL" title={`สวัสดี ${profile.discord_name}`} />

      <section className="card rise flex flex-wrap items-center gap-x-8 gap-y-3">
        <div>
          <p className="font-mono text-xs uppercase tracking-wider text-mute">ยศ</p>
          <RankChip name={profile.rank?.name} color={profile.rank?.color} />
        </div>
        <div>
          <p className="font-mono text-xs uppercase tracking-wider text-mute">ตำแหน่ง</p>
          <p>{profile.position?.name ?? 'ยังไม่ได้รับการแต่งตั้ง'}</p>
        </div>
        <div>
          <p className="font-mono text-xs uppercase tracking-wider text-mute">หน่วยงาน</p>
          <p>{profile.department?.name ?? 'ยังไม่ได้สังกัด'}</p>
        </div>
        <div>
          <p className="font-mono text-xs uppercase tracking-wider text-mute">สถานะ</p>
          <p className="font-semibold text-neon">{profile.is_verified ? 'ยืนยันตัวตนแล้ว' : 'ยังไม่ได้ยืนยัน'}</p>
        </div>
      </section>

      <section className="grid gap-3 sm:grid-cols-2">
        {LINKS.map((l) => (
          <Link key={l.to} to={l.to} className="card-plain block transition hover:border-neon">
            <p className="h-display text-lg">{l.t}</p>
            <p className="text-sm text-mute">{l.d}</p>
          </Link>
        ))}
      </section>

      <section>
        <h2 className="h-display mb-3 text-xl">การแจ้งเตือนล่าสุด</h2>
        {items.length === 0 ? (
          <Empty title="ยังไม่มีการแจ้งเตือน" />
        ) : (
          <div className="space-y-2">
            {items.map((n) => (
              <div key={n.id} className="card-plain">
                <p className="font-display font-semibold">{n.title}</p>
                {n.body && <p className="break-words text-sm text-mute">{n.body}</p>}
                <p className="mt-1 font-mono text-xs text-mute/70">{fmtDate(n.created_at)}</p>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
