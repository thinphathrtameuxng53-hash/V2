import { useEffect, useState } from 'react';
import { useAuth } from '../../lib/auth';
import { supabase } from '../../lib/supabase';
import { ACTION_LABEL, fmtDate, type RankHistory } from '../../lib/types';
import { Empty, PageTitle, RankChip, ShieldLogo } from '../../components/ui';

export function Avatar({ url, name, size = 72 }: { url: string | null; name: string; size?: number }) {
  if (url) return <img src={url} alt={name} width={size} height={size} className="rounded-sm border border-line object-cover" style={{ width: size, height: size }} />;
  return (
    <div className="flex items-center justify-center rounded-sm border border-line bg-panel2 font-display text-2xl font-bold text-neon" style={{ width: size, height: size }}>
      {name.slice(0, 1).toUpperCase()}
    </div>
  );
}

export default function ProfilePage() {
  const { profile, user } = useAuth();
  const [hist, setHist] = useState<RankHistory[] | null>(null);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('rank_history')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .then(({ data }) => setHist((data ?? []) as RankHistory[]));
  }, [user?.id, profile?.rank_id, profile?.position_id, profile?.department_id]);

  if (!profile) return null;

  return (
    <div className="space-y-8">
      <PageTitle eyebrow="PLAYER PROFILE" title="ข้อมูลสมาชิก" />

      {/* บัตรสมาชิก */}
      <section className="card rise max-w-2xl border-royal">
        <div className="mb-4 flex items-center justify-between">
          <span className="eyebrow">CRAZY POLICE • MEMBER ID</span>
          <ShieldLogo size={32} />
        </div>
        <div className="flex flex-wrap gap-5">
          <Avatar url={profile.avatar_url} name={profile.discord_name} size={96} />
          <dl className="grid min-w-0 flex-1 grid-cols-1 gap-x-6 gap-y-3 sm:grid-cols-2">
            <Row k="ชื่อ Discord" v={profile.discord_name} />
            <Row k="ชื่อ Roblox" v={profile.roblox_name ?? '-'} />
            <div>
              <dt className="font-mono text-xs uppercase tracking-wider text-mute">ยศปัจจุบัน</dt>
              <dd className="mt-1">
                <RankChip name={profile.rank?.name} color={profile.rank?.color} />
              </dd>
            </div>
            <Row k="ตำแหน่งปัจจุบัน" v={profile.position?.name ?? 'ยังไม่ได้รับการแต่งตั้ง'} />
            <Row k="หน่วยงานที่สังกัด" v={profile.department?.name ?? 'ยังไม่ได้สังกัด'} />
            <Row k="สถานะสมาชิก" v={profile.is_verified ? 'ยืนยันตัวตนแล้ว' : 'ยังไม่ได้ยืนยัน'} accent />
            <Row k="วันที่ยืนยันตัวตน" v={fmtDate(profile.verified_at)} />
            <Row k="วันที่ได้รับแต่งตั้งยศ" v={profile.appointed_at ? fmtDate(profile.appointed_at) : '-'} />
          </dl>
        </div>
        <p className="mt-4 text-xs text-mute">ยศและตำแหน่งกำหนดโดยแอดมินเท่านั้น สมาชิกไม่สามารถแก้ไขเองได้</p>
      </section>

      <section>
        <h2 className="h-display mb-3 text-xl">ประวัติการเปลี่ยนยศ</h2>
        {!hist ? null : hist.length === 0 ? (
          <Empty title="ยังไม่มีประวัติการเปลี่ยนยศ" />
        ) : (
          <div className="space-y-2">
            {hist.map((h) => (
              <div key={h.id} className="card-plain text-sm">
                <p className="font-display font-semibold">
                  {ACTION_LABEL[h.action] ?? h.action}: {h.old_rank_name ?? 'ประชาชน'} → {h.new_rank_name ?? 'ประชาชน'}
                </p>
                <p className="text-mute">
                  ตำแหน่ง {h.new_position_name ?? '-'} • หน่วยงาน {h.new_department_name ?? '-'}
                </p>
                <p className="break-words">เหตุผล: {h.reason}</p>
                <p className="font-mono text-xs text-mute">
                  โดย {h.changed_by_name ?? '-'} • {fmtDate(h.created_at)}
                </p>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function Row({ k, v, accent }: { k: string; v: string; accent?: boolean }) {
  return (
    <div className="min-w-0">
      <dt className="font-mono text-xs uppercase tracking-wider text-mute">{k}</dt>
      <dd className={`mt-1 break-words ${accent ? 'font-semibold text-neon' : ''}`}>{v}</dd>
    </div>
  );
}
