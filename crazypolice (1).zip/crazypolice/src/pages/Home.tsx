import { Link } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import { ShieldLogo } from '../components/ui';

const TILES = [
  { to: '/verify', title: 'ยืนยันตัวตน', hint: 'ส่งข้อมูลให้ทีมงานตรวจสอบ', primary: true },
  { to: '/portal/rules', title: 'กฎระเบียบแมพ', hint: 'เฉพาะสมาชิกที่ยืนยันแล้ว' },
  { to: '/portal/guide', title: 'วิธีใส่เสื้อเจ้าหน้าที่', hint: 'เฉพาะสมาชิกที่ยืนยันแล้ว' },
  { to: '/portal/complaints', title: 'ระบบร้องเรียน', hint: 'เฉพาะสมาชิกที่ยืนยันแล้ว' },
];

export default function Home() {
  const { user, profile, loading, isAdmin } = useAuth();

  return (
    <div className="min-h-screen">
      <div className="lightbar" />
      <header className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-4">
        <div className="flex items-center gap-2.5">
          <ShieldLogo size={36} />
          <span className="h-display text-lg">CRAZY POLICE</span>
        </div>
        <div className="flex gap-2">
          {isAdmin && (
            <Link to="/admin" className="btn-purple btn-sm">
              หลังบ้านแอดมิน
            </Link>
          )}
          {!loading && !user && (
            <Link to="/login" className="btn-ghost btn-sm">
              เข้าสู่ระบบ
            </Link>
          )}
          {profile?.is_verified && (
            <Link to="/portal" className="btn-primary btn-sm">
              เข้าสู่หน้าสมาชิก
            </Link>
          )}
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-16">
        <section className="grid items-center gap-10 py-10 md:grid-cols-[1.25fr_1fr] md:py-16">
          <div className="rise">
            <p className="eyebrow mb-3">CRAZY POLICE MEMBER PORTAL</p>
            <h1 className="h-display text-4xl leading-tight sm:text-5xl md:text-6xl">
              ยินดีต้อนรับเข้าสู่
              <br />
              <span className="text-neon">CRAZY POLICE</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-mute">
              เว็บไซต์ศูนย์กลางข้อมูลสมาชิก ระบบยืนยันตัวตน กฎระเบียบ และบริการต่าง ๆ สำหรับสมาชิกแมพ CRAZY POLICE
            </p>
          </div>

          {/* บัตรเจ้าหน้าที่ตัวอย่างแบบไม่ใส่ข้อมูลปลอม */}
          <div className="card rise hidden md:block" style={{ animationDelay: '0.15s' }}>
            <div className="flex items-center gap-4">
              <ShieldLogo size={64} />
              <div>
                <p className="eyebrow">STAFF ID</p>
                <p className="h-display text-xl">ยืนยันตัวตนเพื่อรับบัตรสมาชิก</p>
              </div>
            </div>
            <div className="my-4 h-px bg-line" />
            <dl className="grid grid-cols-2 gap-3 font-mono text-xs uppercase tracking-wider text-mute">
              <div>
                <dt>Discord</dt>
                <dd className="mt-1 text-white">Login with Discord</dd>
              </div>
              <div>
                <dt>Roblox</dt>
                <dd className="mt-1 text-white">Name + Evidence</dd>
              </div>
              <div>
                <dt>Review</dt>
                <dd className="mt-1 text-neon">By Admin</dd>
              </div>
              <div>
                <dt>Access</dt>
                <dd className="mt-1 text-white">Member Portal</dd>
              </div>
            </dl>
          </div>
        </section>

        <section aria-label="เมนูหลัก" className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {TILES.map((t, i) => (
            <Link
              key={t.to}
              to={t.to}
              className={`rise block border p-5 transition hover:-translate-y-0.5 ${
                t.primary ? 'border-neon bg-neon text-ink' : 'border-line bg-panel hover:border-royal'
              }`}
              style={{ animationDelay: `${0.1 + i * 0.07}s` }}
            >
              <p className="h-display text-lg">[ {t.title} ]</p>
              <p className={`mt-1 text-sm ${t.primary ? 'text-ink/70' : 'text-mute'}`}>{t.hint}</p>
            </Link>
          ))}
        </section>

        <p className="mt-6 text-sm text-mute">
          ก่อนยืนยันตัวตน สามารถเข้าถึงได้เฉพาะหน้านี้และหน้ายืนยันตัวตน เมื่อทีมงานอนุมัติแล้วจึงเข้าส่วนสมาชิกได้
        </p>
      </main>
    </div>
  );
}
