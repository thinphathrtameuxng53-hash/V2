import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import { supabase, uploadImage } from '../lib/supabase';
import { fmtDate, type VerificationRequest } from '../lib/types';
import { ErrorBox, ImagePicker, ShieldLogo, Spinner, StatusChip } from '../components/ui';

const CITIZEN = 'ยศประชาชน';

export default function Verify() {
  const { user, profile, refreshProfile, signOut, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [req, setReq] = useState<VerificationRequest | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [roblox, setRoblox] = useState('');
  const [rank, setRank] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [justSent, setJustSent] = useState<string | null>(null);

  const loadReq = useCallback(async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from('verification_requests')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();
    if (error) setErr('โหลดสถานะคำขอไม่สำเร็จ: ' + error.message);
    setReq((data as VerificationRequest | null) ?? null);
    setLoaded(true);
  }, [user?.id]);

  useEffect(() => {
    loadReq();
    if (!user) return;
    // อัปเดตสถานะทันทีเมื่อแอดมินอนุมัติ/ปฏิเสธ (ข้อมูลมาจากฐานข้อมูลจริง)
    const ch = supabase
      .channel('vr-' + user.id)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'verification_requests', filter: `user_id=eq.${user.id}` }, () => {
        loadReq();
        refreshProfile();
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [user?.id]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setErr(null);
    const rk = rank.trim();
    if (!roblox.trim()) return setErr('กรุณากรอกชื่อ Roblox');
    if (!rk) return setErr('กรุณาระบุยศหรือตำแหน่ง (ถ้าไม่มี ให้กดปุ่ม "ไม่มียศ")');
    if (rk !== CITIZEN && !file) return setErr('กรุณาแนบรูปหลักฐานยศหรือตำแหน่ง');
    setBusy(true);
    try {
      let path = '';
      if (file) path = await uploadImage('evidence', user!.id, file);
      const { data, error } = await supabase.rpc('submit_verification', {
        p_roblox_name: roblox.trim(),
        p_claimed_rank: rk,
        p_evidence_path: path,
      });
      if (error) throw new Error(error.message);
      const row = data as VerificationRequest;
      if (!row?.request_no) throw new Error('ระบบไม่ได้ยืนยันการบันทึกข้อมูล กรุณาลองใหม่');
      setJustSent(row.request_no);
      setFile(null);
      await loadReq();
    } catch (ex: any) {
      setErr(ex.message ?? 'ส่งข้อมูลไม่สำเร็จ');
    } finally {
      setBusy(false);
    }
  }

  if (!profile || !loaded) return <Spinner />;

  const verified = profile.is_verified;
  const pending = req?.status === 'PENDING';
  const rejected = req?.status === 'REJECTED' && !verified;

  return (
    <div className="min-h-screen">
      <div className="lightbar" />
      <header className="mx-auto flex max-w-3xl items-center justify-between gap-3 px-4 py-4">
        <Link to="/" className="flex items-center gap-2.5">
          <ShieldLogo size={32} />
          <span className="h-display text-lg">CRAZY POLICE</span>
        </Link>
        <button
          className="btn-ghost btn-sm"
          onClick={async () => {
            await signOut();
            navigate('/');
          }}
        >
          ออกจากระบบ
        </button>
      </header>

      <main className="mx-auto max-w-3xl space-y-5 px-4 pb-16">
        <div className="rise">
          <p className="eyebrow">IDENTITY VERIFICATION</p>
          <h1 className="h-display text-3xl">ยืนยันตัวตนสมาชิก</h1>
        </div>

        {verified && (
          <div className="card rise space-y-3 border-neon">
            <StatusChip status="APPROVED" />
            <h2 className="h-display text-2xl text-neon">ยืนยันตัวตนสำเร็จ</h2>
            <p className="text-mute">
              บัญชี {profile.discord_name} (Roblox: {profile.roblox_name ?? '-'}) ได้รับการอนุมัติเมื่อ {fmtDate(profile.verified_at)}
            </p>
            <Link to="/portal" className="btn-primary">
              เข้าสู่หน้าสมาชิก
            </Link>
          </div>
        )}

        {!verified && isAdmin && (
          <div className="card-plain text-sm text-mute">
            คุณเป็นแอดมิน เข้าหลังบ้านได้ที่{' '}
            <Link to="/admin" className="text-neon underline">
              หน้าแอดมิน
            </Link>
          </div>
        )}

        {pending && req && (
          <div className="card rise space-y-3 border-yellow-400/60">
            <StatusChip status="PENDING" />
            {justSent && <p className="font-semibold text-neon">ส่งข้อมูลสำเร็จ บันทึกลงฐานข้อมูลเรียบร้อยแล้ว</p>}
            <h2 className="h-display text-2xl">รอทีมงานตรวจสอบ</h2>
            <dl className="grid gap-2 text-sm sm:grid-cols-2">
              <Info k="หมายเลขคำขอ" v={req.request_no} mono />
              <Info k="ส่งเมื่อ" v={fmtDate(req.created_at)} />
              <Info k="ชื่อ Discord" v={req.discord_name} />
              <Info k="ชื่อ Roblox" v={req.roblox_name} />
              <Info k="ยศ / ตำแหน่งที่แจ้ง" v={req.claimed_rank} />
            </dl>
            <p className="text-sm text-mute">
              ไม่ต้องส่งซ้ำ เมื่อมีผลการตรวจสอบ หน้านี้จะอัปเดตเอง และคุณจะได้รับการแจ้งเตือนบนเว็บไซต์ จะปิดหน้าแล้วกลับมาดูภายหลังก็ได้
            </p>
          </div>
        )}

        {rejected && req && (
          <div className="card rise space-y-2 border-red-400/60">
            <StatusChip status="REJECTED" />
            <h2 className="h-display text-xl">คำขอ {req.request_no} ถูกปฏิเสธ</h2>
            <p className="text-sm">
              <span className="text-mute">เหตุผล: </span>
              {req.reject_reason}
            </p>
            <p className="font-mono text-xs text-mute">
              ตรวจโดย {req.reviewed_by_name ?? '-'} • {fmtDate(req.reviewed_at)}
            </p>
            <p className="text-sm text-mute">แก้ไขข้อมูลตามเหตุผลด้านบน แล้วส่งคำขอใหม่ได้ที่ฟอร์มด้านล่าง</p>
          </div>
        )}

        {!verified && !pending && (
          <form onSubmit={submit} className="card rise space-y-5" noValidate>
            <h2 className="h-display text-xl">ฟอร์มยืนยันตัวตน</h2>

            <div>
              <label className="label" htmlFor="discord">
                ชื่อ Discord
              </label>
              <input id="discord" className="input" value={profile.discord_name} readOnly />
              <p className="mt-1 text-xs text-mute">ดึงจากบัญชี Discord ที่ล็อกอิน แก้ไขเองไม่ได้ เพื่อป้องกันการสวมรอย</p>
            </div>

            <div>
              <label className="label" htmlFor="roblox">
                ชื่อในเกม Roblox <span className="text-neon">*</span>
              </label>
              <input id="roblox" className="input" value={roblox} onChange={(e) => setRoblox(e.target.value)} maxLength={40} autoComplete="off" placeholder="เช่น Username ของคุณ" />
            </div>

            <div>
              <label className="label" htmlFor="rank">
                ยศ / ตำแหน่ง <span className="text-neon">*</span>
              </label>
              <input id="rank" className="input" value={rank} onChange={(e) => setRank(e.target.value)} maxLength={80} placeholder="พิมพ์ยศหรือตำแหน่งที่คุณมี" />
              <button type="button" className="btn-ghost btn-sm mt-2" onClick={() => setRank(CITIZEN)}>
                ไม่มียศ / ตำแหน่ง ({CITIZEN})
              </button>
            </div>

            <ImagePicker file={file} onChange={setFile} label="รูปหลักฐานยศหรือตำแหน่ง" required={rank.trim() !== CITIZEN} />

            <ErrorBox message={err} />
            <button type="submit" className="btn-primary w-full sm:w-auto" disabled={busy}>
              {busy ? 'กำลังส่งข้อมูล...' : 'ส่งข้อมูลยืนยันตัวตน'}
            </button>
          </form>
        )}

        {err && (verified || pending) && <ErrorBox message={err} />}
      </main>
    </div>
  );
}

function Info({ k, v, mono }: { k: string; v: string; mono?: boolean }) {
  return (
    <div>
      <dt className="font-mono text-xs uppercase tracking-wider text-mute">{k}</dt>
      <dd className={`break-words ${mono ? 'font-mono text-neon' : ''}`}>{v}</dd>
    </div>
  );
}
