import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import { ErrorBox, ShieldLogo } from '../components/ui';

export default function Login() {
  const { user, loading, signInWithDiscord } = useAuth();
  const navigate = useNavigate();
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && user) navigate('/verify', { replace: true });
  }, [loading, user, navigate]);

  async function go() {
    setBusy(true);
    setErr(null);
    const e = await signInWithDiscord();
    if (e) {
      setErr('เข้าสู่ระบบไม่สำเร็จ: ' + e);
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-4 py-10">
      <div className="lightbar mb-8" />
      <div className="card rise space-y-5">
        <div className="flex items-center gap-3">
          <ShieldLogo size={48} />
          <div>
            <p className="eyebrow">MEMBER PORTAL</p>
            <h1 className="h-display text-2xl">เข้าสู่ระบบ</h1>
          </div>
        </div>
        <p className="text-sm text-mute">
          ใช้บัญชี Discord ของคุณเพื่อระบุตัวตน ระบบจะรับชื่อ รูปโปรไฟล์ และอีเมลของบัญชี Discord เท่านั้น ไม่มีการขอรหัสผ่านและไม่เข้าถึงเซิร์ฟเวอร์ของคุณ
        </p>
        <ErrorBox message={err} />
        <button className="btn-primary w-full" onClick={go} disabled={busy}>
          {busy ? 'กำลังไปยัง Discord...' : 'เข้าสู่ระบบด้วย Discord'}
        </button>
        <Link to="/" className="block text-center text-sm text-mute hover:text-white">
          กลับหน้าแรก
        </Link>
      </div>
    </div>
  );
}
