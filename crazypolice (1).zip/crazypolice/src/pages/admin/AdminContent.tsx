import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { useAuth } from '../../lib/auth';
import { supabase, uploadImage } from '../../lib/supabase';
import { RULE_CATEGORIES, type GuideItem, type Rule } from '../../lib/types';
import { ConfirmButton, Empty, ErrorBox, ImagePicker, OkBox, PageTitle, SignedImage, Spinner } from '../../components/ui';

export default function AdminContent() {
  const [tab, setTab] = useState<'rules' | 'guide'>('rules');
  return (
    <div className="space-y-6">
      <PageTitle eyebrow="CONTENT" title="จัดการกฎระเบียบและคู่มือ" />
      <div className="flex gap-2" role="tablist">
        <button role="tab" aria-selected={tab === 'rules'} className={tab === 'rules' ? 'btn-primary btn-sm' : 'btn-ghost btn-sm'} onClick={() => setTab('rules')}>
          กฎระเบียบ
        </button>
        <button role="tab" aria-selected={tab === 'guide'} className={tab === 'guide' ? 'btn-primary btn-sm' : 'btn-ghost btn-sm'} onClick={() => setTab('guide')}>
          คู่มือใส่เสื้อเจ้าหน้าที่
        </button>
      </div>
      {tab === 'rules' ? <RulesEditor /> : <GuideEditor />}
    </div>
  );
}

function RulesEditor() {
  const { user } = useAuth();
  const [rows, setRows] = useState<Rule[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [editId, setEditId] = useState<string | null>(null);
  const [category, setCategory] = useState(RULE_CATEGORIES[0]);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [order, setOrder] = useState(0);
  const [published, setPublished] = useState(true);

  const load = useCallback(async () => {
    const { data, error } = await supabase.from('rules').select('*').order('category').order('sort_order');
    if (error) setErr(error.message);
    setRows((data ?? []) as Rule[]);
  }, []);
  useEffect(() => {
    load();
  }, [load]);

  function reset() {
    setEditId(null);
    setTitle('');
    setBody('');
    setOrder(0);
    setPublished(true);
  }

  async function save(e: FormEvent) {
    e.preventDefault();
    setErr(null);
    setOk(null);
    if (!title.trim()) return setErr('กรุณากรอกหัวข้อกฎ');
    const payload = { category: category.trim(), title: title.trim(), body, sort_order: order, is_published: published, updated_by: user!.id, updated_at: new Date().toISOString() };
    const { error } = editId ? await supabase.from('rules').update(payload).eq('id', editId) : await supabase.from('rules').insert(payload);
    if (error) return setErr(error.message);
    setOk(editId ? 'แก้ไขกฎแล้ว' : 'เพิ่มกฎแล้ว');
    reset();
    load();
  }

  async function del(id: string) {
    const { error } = await supabase.from('rules').delete().eq('id', id);
    if (error) return setErr(error.message);
    setOk('ลบกฎแล้ว');
    if (editId === id) reset();
    load();
  }

  return (
    <div className="space-y-5">
      <form onSubmit={save} className="card space-y-3">
        <h2 className="h-display text-xl">{editId ? 'แก้ไขกฎ' : 'เพิ่มกฎใหม่'}</h2>
        <div className="grid gap-3 sm:grid-cols-[2fr_1fr]">
          <div>
            <label className="label" htmlFor="cat">
              หมวดหมู่
            </label>
            <input id="cat" list="cats" className="input" value={category} onChange={(e) => setCategory(e.target.value)} />
            <datalist id="cats">
              {RULE_CATEGORIES.map((c) => (
                <option key={c} value={c} />
              ))}
            </datalist>
          </div>
          <div>
            <label className="label" htmlFor="ord">
              ลำดับ
            </label>
            <input id="ord" type="number" className="input" value={order} onChange={(e) => setOrder(Number(e.target.value))} />
          </div>
        </div>
        <div>
          <label className="label" htmlFor="rtitle">
            หัวข้อ
          </label>
          <input id="rtitle" className="input" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} />
        </div>
        <div>
          <label className="label" htmlFor="rbody">
            รายละเอียด
          </label>
          <textarea id="rbody" className="input min-h-28" value={body} onChange={(e) => setBody(e.target.value)} />
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={published} onChange={(e) => setPublished(e.target.checked)} className="h-4 w-4 accent-[#39FF88]" />
          แสดงให้สมาชิกเห็น
        </label>
        <ErrorBox message={err} />
        <OkBox message={ok} />
        <div className="flex gap-2">
          <button className="btn-primary" type="submit">
            {editId ? 'บันทึกการแก้ไข' : 'เพิ่มกฎ'}
          </button>
          {editId && (
            <button type="button" className="btn-ghost" onClick={reset}>
              ยกเลิกแก้ไข
            </button>
          )}
        </div>
      </form>

      {!rows ? (
        <Spinner />
      ) : rows.length === 0 ? (
        <Empty title="ยังไม่มีกฎ" hint="เพิ่มกฎแรกจากฟอร์มด้านบน" />
      ) : (
        <ul className="space-y-2">
          {rows.map((r) => (
            <li key={r.id} className="card-plain space-y-1">
              <p className="font-mono text-xs text-neon">
                {r.category} • ลำดับ {r.sort_order} {r.is_published ? '' : '• ซ่อนอยู่'}
              </p>
              <p className="font-display text-lg font-semibold">{r.title}</p>
              <p className="line-clamp-2 whitespace-pre-wrap break-words text-sm text-mute">{r.body}</p>
              <div className="flex gap-2 pt-1">
                <button
                  className="btn-ghost btn-sm"
                  onClick={() => {
                    setEditId(r.id);
                    setCategory(r.category);
                    setTitle(r.title);
                    setBody(r.body);
                    setOrder(r.sort_order);
                    setPublished(r.is_published);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                >
                  แก้ไข
                </button>
                <ConfirmButton label="ลบ" onConfirm={() => del(r.id)} />
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function GuideEditor() {
  const { user } = useAuth();
  const [rows, setRows] = useState<GuideItem[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [editId, setEditId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [order, setOrder] = useState(0);
  const [file, setFile] = useState<File | null>(null);
  const [keepPath, setKeepPath] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const { data, error } = await supabase.from('guide_items').select('*').order('sort_order').order('created_at');
    if (error) setErr(error.message);
    setRows((data ?? []) as GuideItem[]);
  }, []);
  useEffect(() => {
    load();
  }, [load]);

  function reset() {
    setEditId(null);
    setTitle('');
    setBody('');
    setOrder(0);
    setFile(null);
    setKeepPath(null);
  }

  async function save(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setErr(null);
    setOk(null);
    if (!title.trim()) return setErr('กรุณากรอกหัวข้อ');
    setBusy(true);
    try {
      let image_path = keepPath;
      if (file) image_path = await uploadImage('guide', 'steps', file);
      const payload = { title: title.trim(), body, sort_order: order, image_path, updated_by: user!.id, updated_at: new Date().toISOString() };
      const { error } = editId ? await supabase.from('guide_items').update(payload).eq('id', editId) : await supabase.from('guide_items').insert(payload);
      if (error) throw new Error(error.message);
      setOk(editId ? 'แก้ไขแล้ว' : 'เพิ่มขั้นตอนแล้ว');
      reset();
      load();
    } catch (ex: any) {
      setErr(ex.message);
    } finally {
      setBusy(false);
    }
  }

  async function del(g: GuideItem) {
    const { error } = await supabase.from('guide_items').delete().eq('id', g.id);
    if (error) return setErr(error.message);
    if (g.image_path) await supabase.storage.from('guide').remove([g.image_path]);
    setOk('ลบแล้ว');
    load();
  }

  return (
    <div className="space-y-5">
      <form onSubmit={save} className="card space-y-3">
        <h2 className="h-display text-xl">{editId ? 'แก้ไขขั้นตอน' : 'เพิ่มขั้นตอนคู่มือ'}</h2>
        <div className="grid gap-3 sm:grid-cols-[3fr_1fr]">
          <div>
            <label className="label" htmlFor="gtitle">
              หัวข้อ
            </label>
            <input id="gtitle" className="input" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} />
          </div>
          <div>
            <label className="label" htmlFor="gord">
              ลำดับ
            </label>
            <input id="gord" type="number" className="input" value={order} onChange={(e) => setOrder(Number(e.target.value))} />
          </div>
        </div>
        <div>
          <label className="label" htmlFor="gbody">
            คำอธิบาย
          </label>
          <textarea id="gbody" className="input min-h-24" value={body} onChange={(e) => setBody(e.target.value)} />
        </div>
        {editId && keepPath && !file && (
          <div>
            <p className="label">รูปปัจจุบัน</p>
            <SignedImage bucket="guide" path={keepPath} alt="รูปปัจจุบัน" className="max-h-48 rounded-sm" />
            <button type="button" className="btn-danger btn-sm mt-2" onClick={() => setKeepPath(null)}>
              ลบรูปนี้ออกจากขั้นตอน
            </button>
          </div>
        )}
        <ImagePicker file={file} onChange={setFile} label="รูปประกอบ (ถ้ามี)" />
        <ErrorBox message={err} />
        <OkBox message={ok} />
        <div className="flex gap-2">
          <button className="btn-primary" type="submit" disabled={busy}>
            {busy ? 'กำลังบันทึก...' : editId ? 'บันทึกการแก้ไข' : 'เพิ่มขั้นตอน'}
          </button>
          {editId && (
            <button type="button" className="btn-ghost" onClick={reset}>
              ยกเลิกแก้ไข
            </button>
          )}
        </div>
      </form>

      {!rows ? (
        <Spinner />
      ) : rows.length === 0 ? (
        <Empty title="ยังไม่มีคู่มือ" hint="เพิ่มขั้นตอนแรกจากฟอร์มด้านบน สมาชิกจะเห็นข้อความ 'ยังไม่มีคู่มือ' จนกว่าจะมีข้อมูล" />
      ) : (
        <ul className="space-y-2">
          {rows.map((g) => (
            <li key={g.id} className="card-plain space-y-1">
              <p className="font-mono text-xs text-neon">ลำดับ {g.sort_order}</p>
              <p className="font-display text-lg font-semibold">{g.title}</p>
              <p className="line-clamp-2 whitespace-pre-wrap break-words text-sm text-mute">{g.body}</p>
              {g.image_path && <SignedImage bucket="guide" path={g.image_path} alt={g.title} className="max-h-32 rounded-sm" />}
              <div className="flex gap-2 pt-1">
                <button
                  className="btn-ghost btn-sm"
                  onClick={() => {
                    setEditId(g.id);
                    setTitle(g.title);
                    setBody(g.body);
                    setOrder(g.sort_order);
                    setKeepPath(g.image_path);
                    setFile(null);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                >
                  แก้ไข
                </button>
                <ConfirmButton label="ลบ" onConfirm={() => del(g)} />
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
