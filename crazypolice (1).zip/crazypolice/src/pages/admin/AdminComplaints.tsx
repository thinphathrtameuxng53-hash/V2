import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { fmtDate, type Complaint, type ComplaintStatus } from '../../lib/types';
import { Empty, ErrorBox, Modal, OkBox, PageTitle, SignedImage, Spinner, StatusChip } from '../../components/ui';

const STATUSES: ComplaintStatus[] = ['PENDING', 'IN_REVIEW', 'RESOLVED', 'REJECTED'];

export default function AdminComplaints() {
  const [rows, setRows] = useState<(Complaint & { reporter?: { discord_name: string; roblox_name: string | null } })[] | null>(null);
  const [filter, setFilter] = useState<'ALL' | ComplaintStatus>('ALL');
  const [sel, setSel] = useState<Complaint | null>(null);
  const [status, setStatus] = useState<ComplaintStatus>('PENDING');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data, error } = await supabase.from('complaints').select('*, reporter:profiles!complaints_user_id_fkey(discord_name,roblox_name)').order('created_at', { ascending: false });
    if (error) {
      // กรณี embed ไม่ได้ ให้โหลดตารางเดี่ยวแทน
      const r2 = await supabase.from('complaints').select('*').order('created_at', { ascending: false });
      if (r2.error) setErr(r2.error.message);
      setRows((r2.data ?? []) as any);
      return;
    }
    setRows((data ?? []) as any);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function save() {
    if (!sel) return;
    setBusy(true);
    setErr(null);
    const { error } = await supabase.rpc('update_complaint', { p_id: sel.id, p_status: status, p_note: note });
    setBusy(false);
    if (error) return setErr(error.message);
    setOk(`อัปเดต ${sel.complaint_no} แล้ว และแจ้งเตือนผู้ร้องเรียนแล้ว`);
    setSel(null);
    load();
  }

  if (!rows) return <Spinner />;
  const shown = filter === 'ALL' ? rows : rows.filter((r) => r.status === filter);

  return (
    <div className="space-y-6">
      <PageTitle eyebrow="COMPLAINTS" title="เรื่องร้องเรียน" />
      <div className="flex flex-wrap gap-2">
        {(['ALL', ...STATUSES] as const).map((s) => (
          <button key={s} className={filter === s ? 'btn-primary btn-sm' : 'btn-ghost btn-sm'} onClick={() => setFilter(s as any)}>
            {s === 'ALL' ? 'ทั้งหมด' : s.replace('_', ' ')}
          </button>
        ))}
      </div>
      <ErrorBox message={err} />
      <OkBox message={ok} />
      {shown.length === 0 ? (
        <Empty title="ไม่มีเรื่องร้องเรียน" />
      ) : (
        <div className="space-y-2">
          {shown.map((c) => (
            <button
              key={c.id}
              className="card-plain flex w-full flex-wrap items-center justify-between gap-2 text-left transition hover:border-neon"
              onClick={() => {
                setSel(c);
                setStatus(c.status);
                setNote(c.admin_note ?? '');
                setErr(null);
              }}
            >
              <span className="min-w-0">
                <span className="block font-mono text-xs text-neon">{c.complaint_no}</span>
                <span className="block truncate font-display font-semibold">{c.subject}</span>
                <span className="block font-mono text-xs text-mute">
                  ผู้ร้อง: {c.reporter?.discord_name ?? '-'} • ผู้ถูกร้อง: {c.accused_name} • {fmtDate(c.created_at)}
                </span>
              </span>
              <StatusChip status={c.status} />
            </button>
          ))}
        </div>
      )}

      {sel && (
        <Modal title={sel.complaint_no} onClose={() => setSel(null)} wide>
          <div className="space-y-3 text-sm">
            <p className="font-display text-lg font-semibold">{sel.subject}</p>
            <p>
              <span className="text-mute">ผู้ถูกร้องเรียน: </span>
              {sel.accused_name}
            </p>
            <p className="whitespace-pre-wrap break-words">{sel.details}</p>
            {sel.evidence_path && <SignedImage bucket="evidence" path={sel.evidence_path} alt="หลักฐาน" />}
            <div className="grid gap-3 sm:grid-cols-[1fr_2fr]">
              <div>
                <label className="label" htmlFor="st">
                  สถานะ
                </label>
                <select id="st" className="input" value={status} onChange={(e) => setStatus(e.target.value as ComplaintStatus)}>
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {s.replace('_', ' ')}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label" htmlFor="nt">
                  หมายเหตุถึงผู้ร้องเรียน
                </label>
                <textarea id="nt" className="input min-h-20" value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} />
              </div>
            </div>
            {sel.handled_by_name && (
              <p className="font-mono text-xs text-mute">
                ดำเนินการล่าสุดโดย {sel.handled_by_name} • {fmtDate(sel.handled_at)}
              </p>
            )}
            <ErrorBox message={err} />
            <button className="btn-primary" onClick={save} disabled={busy}>
              {busy ? 'กำลังบันทึก...' : 'บันทึกสถานะ'}
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
