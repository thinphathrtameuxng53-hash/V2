import { useCallback, useEffect, useState } from 'react';
import { useAuth } from '../../lib/auth';
import { supabase } from '../../lib/supabase';
import { ACTION_LABEL, fmtDate, PROFILE_SELECT, type Option, type Profile, type RankHistory, type Role } from '../../lib/types';
import { Empty, ErrorBox, Modal, OkBox, PageTitle, RankChip, Spinner } from '../../components/ui';
import { Avatar } from '../portal/ProfilePage';

const ACTIONS = ['assign', 'change', 'promote', 'demote', 'remove', 'assignment'] as const;

export default function AdminMembers() {
  const { isSuperAdmin, user } = useAuth();
  const [q, setQ] = useState('');
  const [members, setMembers] = useState<Profile[] | null>(null);
  const [ranks, setRanks] = useState<Option[]>([]);
  const [positions, setPositions] = useState<Option[]>([]);
  const [departments, setDepartments] = useState<Option[]>([]);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [edit, setEdit] = useState<Profile | null>(null);
  const [histFor, setHistFor] = useState<Profile | null>(null);

  const loadMembers = useCallback(async (term: string) => {
    let query = supabase.from('profiles').select(PROFILE_SELECT).eq('is_verified', true).order('discord_name').limit(100);
    const t = term.trim().replace(/[%,()]/g, '');
    if (t) query = query.or(`discord_name.ilike.%${t}%,roblox_name.ilike.%${t}%`);
    const { data, error } = await query;
    if (error) setErr(error.message);
    setMembers((data ?? []) as unknown as Profile[]);
  }, []);

  const loadLists = useCallback(async () => {
    const [r, p, d] = await Promise.all([
      supabase.from('ranks').select('*').eq('is_active', true).order('sort_order'),
      supabase.from('positions').select('*').eq('is_active', true).order('sort_order'),
      supabase.from('departments').select('*').eq('is_active', true).order('sort_order'),
    ]);
    setRanks((r.data ?? []) as Option[]);
    setPositions((p.data ?? []) as Option[]);
    setDepartments((d.data ?? []) as Option[]);
  }, []);

  useEffect(() => {
    loadLists();
  }, [loadLists]);

  useEffect(() => {
    const t = setTimeout(() => loadMembers(q), 250);
    return () => clearTimeout(t);
  }, [q, loadMembers]);

  async function setRole(m: Profile, role: Role) {
    setErr(null);
    setOk(null);
    const { error } = await supabase.rpc('set_user_role', { p_user: m.id, p_role: role });
    if (error) return setErr(error.message);
    setOk(`ตั้งสิทธิ์ ${m.discord_name} เป็น ${role} แล้ว`);
    loadMembers(q);
  }

  return (
    <div className="space-y-6">
      <PageTitle eyebrow="PERSONNEL" title="สมาชิกและยศ" />
      <div>
        <label className="label" htmlFor="q">
          ค้นหาจากชื่อ Discord หรือ Roblox
        </label>
        <input id="q" className="input max-w-md" value={q} onChange={(e) => setQ(e.target.value)} placeholder="พิมพ์ชื่อเพื่อค้นหา" />
      </div>
      <ErrorBox message={err} />
      <OkBox message={ok} />

      {!members ? (
        <Spinner />
      ) : members.length === 0 ? (
        <Empty title="ไม่พบสมาชิก" hint="แสดงเฉพาะสมาชิกที่ผ่านการยืนยันตัวตนแล้ว" />
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {members.map((m) => (
            <div key={m.id} className="card-plain space-y-3">
              <div className="flex gap-3">
                <Avatar url={m.avatar_url} name={m.discord_name} size={56} />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-display text-lg font-semibold">{m.discord_name}</p>
                  <p className="truncate text-sm text-mute">Roblox: {m.roblox_name ?? '-'}</p>
                  <div className="mt-1 flex flex-wrap items-center gap-2">
                    <RankChip name={m.rank?.name} color={m.rank?.color} />
                    {m.role !== 'member' && <span className="chip border-royal text-royal">{m.role}</span>}
                  </div>
                </div>
              </div>
              <p className="text-sm text-mute">
                {m.position?.name ?? 'ยังไม่ได้รับการแต่งตั้ง'} • {m.department?.name ?? 'ยังไม่ได้สังกัด'}
              </p>
              <div className="flex flex-wrap items-center gap-2">
                <button className="btn-primary btn-sm" onClick={() => setEdit(m)}>
                  จัดการยศ
                </button>
                <button className="btn-ghost btn-sm" onClick={() => setHistFor(m)}>
                  ประวัติยศ
                </button>
                {isSuperAdmin && m.id !== user?.id && (
                  <select
                    aria-label={`สิทธิ์ของ ${m.discord_name}`}
                    className="input !w-auto py-1.5 text-sm"
                    value={m.role}
                    onChange={(e) => setRole(m, e.target.value as Role)}
                  >
                    <option value="member">member</option>
                    <option value="admin">admin</option>
                    <option value="super_admin">super_admin</option>
                  </select>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {edit && (
        <AssignModal
          member={edit}
          ranks={ranks}
          positions={positions}
          departments={departments}
          onClose={() => setEdit(null)}
          onDone={(msg) => {
            setEdit(null);
            setOk(msg);
            loadMembers(q);
          }}
        />
      )}
      {histFor && <HistoryModal member={histFor} onClose={() => setHistFor(null)} />}
    </div>
  );
}

function AssignModal({
  member,
  ranks,
  positions,
  departments,
  onClose,
  onDone,
}: {
  member: Profile;
  ranks: Option[];
  positions: Option[];
  departments: Option[];
  onClose: () => void;
  onDone: (msg: string) => void;
}) {
  const [action, setAction] = useState<(typeof ACTIONS)[number]>(member.rank_id ? 'change' : 'assign');
  const [rank, setRank] = useState(member.rank_id ?? '');
  const [pos, setPos] = useState(member.position_id ?? '');
  const [dep, setDep] = useState(member.department_id ?? '');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const needsRank = action !== 'remove' && action !== 'assignment';

  async function save() {
    setErr(null);
    if (!reason.trim()) return setErr('กรุณาระบุเหตุผล');
    if (needsRank && !rank) return setErr('กรุณาเลือกยศ');
    setBusy(true);
    const { error } = await supabase.rpc('set_member_assignment', {
      p_user: member.id,
      p_action: action,
      p_rank: action === 'remove' ? null : action === 'assignment' ? member.rank_id : rank || null,
      p_position: pos || null,
      p_department: dep || null,
      p_reason: reason,
    });
    setBusy(false);
    if (error) return setErr(error.message);
    onDone(`บันทึกการเปลี่ยนแปลงของ ${member.discord_name} แล้ว และแจ้งเตือนผู้เล่นเรียบร้อย`);
  }

  return (
    <Modal title={`จัดการยศ: ${member.discord_name}`} onClose={onClose}>
      <div className="space-y-4">
        <div>
          <label className="label" htmlFor="act">
            การดำเนินการ
          </label>
          <select id="act" className="input" value={action} onChange={(e) => setAction(e.target.value as any)}>
            {ACTIONS.map((a) => (
              <option key={a} value={a}>
                {ACTION_LABEL[a]}
              </option>
            ))}
          </select>
        </div>
        {needsRank && (
          <div>
            <label className="label" htmlFor="rank">
              ยศ
            </label>
            <select id="rank" className="input" value={rank} onChange={(e) => setRank(e.target.value)}>
              <option value="">— เลือกยศ —</option>
              {ranks.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </select>
            {ranks.length === 0 && <p className="mt-1 text-xs text-yellow-300">ยังไม่มียศในระบบ ให้ Super Admin เพิ่มที่ RANK MANAGEMENT</p>}
          </div>
        )}
        <div>
          <label className="label" htmlFor="pos">
            ตำแหน่งหน้าที่
          </label>
          <select id="pos" className="input" value={pos} onChange={(e) => setPos(e.target.value)}>
            <option value="">ยังไม่ได้รับการแต่งตั้ง</option>
            {positions.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="dep">
            หน่วยงานที่สังกัด
          </label>
          <select id="dep" className="input" value={dep} onChange={(e) => setDep(e.target.value)}>
            <option value="">ยังไม่ได้สังกัด</option>
            {departments.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="why">
            เหตุผล (บังคับ)
          </label>
          <textarea id="why" className="input min-h-20" value={reason} onChange={(e) => setReason(e.target.value)} maxLength={500} />
        </div>
        <ErrorBox message={err} />
        <div className="flex gap-2">
          <button className="btn-primary" onClick={save} disabled={busy}>
            {busy ? 'กำลังบันทึก...' : 'บันทึก'}
          </button>
          <button className="btn-ghost" onClick={onClose}>
            ยกเลิก
          </button>
        </div>
      </div>
    </Modal>
  );
}

function HistoryModal({ member, onClose }: { member: Profile; onClose: () => void }) {
  const [rows, setRows] = useState<RankHistory[] | null>(null);
  useEffect(() => {
    supabase
      .from('rank_history')
      .select('*')
      .eq('user_id', member.id)
      .order('created_at', { ascending: false })
      .then(({ data }) => setRows((data ?? []) as RankHistory[]));
  }, [member.id]);
  return (
    <Modal title={`ประวัติยศ: ${member.discord_name}`} onClose={onClose}>
      {!rows ? (
        <Spinner />
      ) : rows.length === 0 ? (
        <Empty title="ยังไม่มีประวัติ" />
      ) : (
        <div className="space-y-2">
          {rows.map((h) => (
            <div key={h.id} className="border border-line bg-ink p-3 text-sm">
              <p className="font-display font-semibold">
                {ACTION_LABEL[h.action] ?? h.action}: {h.old_rank_name ?? 'ประชาชน'} → {h.new_rank_name ?? 'ประชาชน'}
              </p>
              <p className="text-mute">
                ตำแหน่ง {h.old_position_name ?? '-'} → {h.new_position_name ?? '-'} • หน่วยงาน {h.old_department_name ?? '-'} → {h.new_department_name ?? '-'}
              </p>
              <p className="break-words">เหตุผล: {h.reason}</p>
              <p className="font-mono text-xs text-mute">
                โดย {h.changed_by_name ?? '-'} • {fmtDate(h.created_at)}
              </p>
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
}
