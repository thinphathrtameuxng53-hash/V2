import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { fmtDate, type RequestStatus, type VerificationRequest } from '../../lib/types';
import { Empty, ErrorBox, Modal, OkBox, PageTitle, SignedImage, Spinner, StatusChip } from '../../components/ui';

type Filter = 'ALL' | RequestStatus;

export default function AdminHome() {
  const [rows, setRows] = useState<VerificationRequest[] | null>(null);
  const [filter, setFilter] = useState<Filter>('PENDING');
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [evidence, setEvidence] = useState<VerificationRequest | null>(null);
  const [rejecting, setRejecting] = useState<VerificationRequest | null>(null);
  const [reason, setReason] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data, error } = await supabase.from('verification_requests').select('*').order('created_at', { ascending: false });
    if (error) setErr(error.message);
    setRows((data ?? []) as VerificationRequest[]);
  }, []);

  useEffect(() => {
    load();
    const ch = supabase
      .channel('admin-vr')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'verification_requests' }, () => load())
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [load]);

  async function review(r: VerificationRequest, approve: boolean, why?: string) {
    setBusyId(r.id);
    setErr(null);
    setOk(null);
    const { error } = await supabase.rpc('review_verification', { p_request: r.id, p_approve: approve, p_reason: why ?? null });
    setBusyId(null);
    if (error) return setErr(error.message);
    setOk(approve ? `อนุมัติ ${r.request_no} แล้ว` : `ปฏิเสธ ${r.request_no} แล้ว`);
    setRejecting(null);
    setReason('');
    load();
  }

  if (!rows) return <Spinner />;

  const count = (s: RequestStatus) => rows.filter((r) => r.status === s).length;
  const shown = filter === 'ALL' ? rows : rows.filter((r) => r.status === filter);

  const stats: { label: string; value: number; tone: string }[] = [
    { label: 'คำขอทั้งหมด', value: rows.length, tone: 'text-white' },
    { label: 'รอตรวจสอบ', value: count('PENDING'), tone: 'text-yellow-300' },
    { label: 'อนุมัติแล้ว', value: count('APPROVED'), tone: 'text-neon' },
    { label: 'ปฏิเสธแล้ว', value: count('REJECTED'), tone: 'text-red-300' },
  ];

  return (
    <div className="space-y-6">
      <PageTitle eyebrow="ADMIN CONSOLE" title="แดชบอร์ดคำขอยืนยันตัวตน" />

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="card-plain rise">
            <p className="text-sm text-mute">{s.label}</p>
            <p className={`font-display text-4xl font-bold tabular-nums ${s.tone}`}>{s.value}</p>
          </div>
        ))}
      </section>

      <div className="flex flex-wrap gap-2" role="tablist" aria-label="กรองสถานะ">
        {(['PENDING', 'APPROVED', 'REJECTED', 'ALL'] as Filter[]).map((f) => (
          <button key={f} role="tab" aria-selected={filter === f} onClick={() => setFilter(f)} className={filter === f ? 'btn-primary btn-sm' : 'btn-ghost btn-sm'}>
            {f === 'ALL' ? 'ทั้งหมด' : f}
          </button>
        ))}
      </div>

      <ErrorBox message={err} />
      <OkBox message={ok} />

      {shown.length === 0 ? (
        <Empty title="ไม่มีรายการ" hint="ยังไม่มีคำขอในสถานะนี้" />
      ) : (
        <div className="overflow-x-auto border border-line">
          <table className="w-full min-w-[860px] text-left text-sm">
            <thead className="bg-panel2 font-mono text-xs uppercase tracking-wider text-mute">
              <tr>
                <th className="p-3">หมายเลข</th>
                <th className="p-3">Discord</th>
                <th className="p-3">Roblox</th>
                <th className="p-3">ยศ/ตำแหน่ง</th>
                <th className="p-3">ส่งเมื่อ</th>
                <th className="p-3">สถานะ</th>
                <th className="p-3">การดำเนินการ</th>
              </tr>
            </thead>
            <tbody>
              {shown.map((r) => (
                <tr key={r.id} className="border-t border-line align-top">
                  <td className="p-3 font-mono text-neon">{r.request_no}</td>
                  <td className="p-3 break-all">{r.discord_name}</td>
                  <td className="p-3 break-all">{r.roblox_name}</td>
                  <td className="p-3">{r.claimed_rank}</td>
                  <td className="p-3 whitespace-nowrap font-mono text-xs">{fmtDate(r.created_at)}</td>
                  <td className="p-3">
                    <StatusChip status={r.status} />
                    {r.reviewed_by_name && (
                      <p className="mt-1 font-mono text-[11px] text-mute">
                        โดย {r.reviewed_by_name}
                        <br />
                        {fmtDate(r.reviewed_at)}
                      </p>
                    )}
                    {r.reject_reason && <p className="mt-1 max-w-[14rem] break-words text-xs text-red-200">{r.reject_reason}</p>}
                  </td>
                  <td className="p-3">
                    <div className="flex flex-wrap gap-1.5">
                      <button className="btn-ghost btn-sm" onClick={() => setEvidence(r)} disabled={!r.evidence_path}>
                        ดูหลักฐาน
                      </button>
                      {r.status === 'PENDING' && (
                        <>
                          <button className="btn-primary btn-sm" disabled={busyId === r.id} onClick={() => review(r, true)}>
                            อนุมัติ
                          </button>
                          <button className="btn-danger btn-sm" disabled={busyId === r.id} onClick={() => setRejecting(r)}>
                            ปฏิเสธ
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {evidence && (
        <Modal title={`หลักฐาน ${evidence.request_no}`} onClose={() => setEvidence(null)} wide>
          <p className="mb-2 text-sm text-mute">
            {evidence.discord_name} / {evidence.roblox_name} • แจ้งว่า: {evidence.claimed_rank}
          </p>
          {evidence.evidence_path ? <SignedImage bucket="evidence" path={evidence.evidence_path} alt="รูปหลักฐาน" /> : <Empty title="ไม่มีรูปหลักฐาน" />}
        </Modal>
      )}

      {rejecting && (
        <Modal title={`ปฏิเสธ ${rejecting.request_no}`} onClose={() => setRejecting(null)}>
          <label className="label" htmlFor="reason">
            เหตุผลที่ปฏิเสธ (สมาชิกจะเห็นข้อความนี้)
          </label>
          <textarea id="reason" className="input min-h-28" value={reason} onChange={(e) => setReason(e.target.value)} maxLength={500} />
          <div className="mt-4 flex gap-2">
            <button className="btn-danger" disabled={!reason.trim() || busyId === rejecting.id} onClick={() => review(rejecting, false, reason)}>
              ยืนยันปฏิเสธ
            </button>
            <button className="btn-ghost" onClick={() => setRejecting(null)}>
              ยกเลิก
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
