import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { supabase } from '../../lib/supabase';
import type { Option } from '../../lib/types';
import { ConfirmButton, Empty, ErrorBox, OkBox, PageTitle, Spinner } from '../../components/ui';

type Table = 'ranks' | 'positions' | 'departments';
const TABS: { t: Table; label: string; usage: string }[] = [
  { t: 'ranks', label: 'ยศ', usage: 'rank_id' },
  { t: 'positions', label: 'ตำแหน่ง', usage: 'position_id' },
  { t: 'departments', label: 'หน่วยงาน', usage: 'department_id' },
];

export default function AdminRanks() {
  const [tab, setTab] = useState<Table>('ranks');
  const cur = TABS.find((x) => x.t === tab)!;
  const [rows, setRows] = useState<Option[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [color, setColor] = useState('#7B2CBF');
  const [editId, setEditId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  const load = useCallback(async () => {
    setRows(null);
    const { data, error } = await supabase.from(tab).select('*').order('sort_order').order('created_at');
    if (error) setErr(error.message);
    setRows((data ?? []) as Option[]);
  }, [tab]);

  useEffect(() => {
    setErr(null);
    setOk(null);
    setEditId(null);
    load();
  }, [load]);

  async function add(e: FormEvent) {
    e.preventDefault();
    if (!name.trim() || !rows) return;
    setErr(null);
    const next = rows.length ? Math.max(...rows.map((r) => r.sort_order)) + 10 : 10;
    const payload: any = { name: name.trim(), sort_order: next };
    if (tab === 'ranks') payload.color = color;
    const { error } = await supabase.from(tab).insert(payload);
    if (error) return setErr(error.code === '23505' ? 'ชื่อนี้มีอยู่แล้ว' : error.message);
    setName('');
    setOk(`เพิ่ม "${payload.name}" แล้ว`);
    load();
  }

  async function patch(id: string, values: Partial<Option>) {
    setErr(null);
    setOk(null);
    const { error } = await supabase.from(tab).update(values).eq('id', id);
    if (error) return setErr(error.code === '23505' ? 'ชื่อนี้มีอยู่แล้ว' : error.message);
    load();
  }

  async function move(i: number, dir: -1 | 1) {
    if (!rows) return;
    const a = rows[i];
    const b = rows[i + dir];
    if (!b) return;
    // สลับลำดับกัน ถ้าลำดับเท่ากันให้ดันเป็นค่าที่ต่างกัน
    const sa = a.sort_order === b.sort_order ? b.sort_order + dir : b.sort_order;
    const sb = a.sort_order;
    await Promise.all([supabase.from(tab).update({ sort_order: sa }).eq('id', a.id), supabase.from(tab).update({ sort_order: sb }).eq('id', b.id)]);
    load();
  }

  async function remove(r: Option) {
    setErr(null);
    setOk(null);
    const { count, error: cErr } = await supabase.from('profiles').select('id', { count: 'exact', head: true }).eq(cur.usage, r.id);
    if (cErr) return setErr(cErr.message);
    if ((count ?? 0) > 0) {
      return setErr(`ลบ "${r.name}" ไม่ได้ เพราะมีผู้เล่น ${count} คนใช้งานอยู่ ให้ย้ายผู้เล่นไปยศอื่นก่อน หรือกดปิดการใช้งานแทน`);
    }
    const { error } = await supabase.from(tab).delete().eq('id', r.id);
    if (error) return setErr(error.message);
    setOk(`ลบ "${r.name}" แล้ว`);
    load();
  }

  return (
    <div className="space-y-6">
      <PageTitle eyebrow="SUPER ADMIN ONLY" title="RANK MANAGEMENT" />
      <div className="flex flex-wrap gap-2" role="tablist">
        {TABS.map((x) => (
          <button key={x.t} role="tab" aria-selected={tab === x.t} className={tab === x.t ? 'btn-primary btn-sm' : 'btn-ghost btn-sm'} onClick={() => setTab(x.t)}>
            {x.label}
          </button>
        ))}
      </div>

      <form onSubmit={add} className="card-plain flex flex-wrap items-end gap-3">
        <div className="min-w-[12rem] flex-1">
          <label className="label" htmlFor="newname">
            เพิ่ม{cur.label}ใหม่
          </label>
          <input id="newname" className="input" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} />
        </div>
        {tab === 'ranks' && (
          <div>
            <label className="label" htmlFor="newcolor">
              สีประจำยศ
            </label>
            <input id="newcolor" type="color" className="h-11 w-16 cursor-pointer border border-line bg-ink p-1" value={color} onChange={(e) => setColor(e.target.value)} />
          </div>
        )}
        <button className="btn-primary" type="submit" disabled={!name.trim()}>
          เพิ่ม
        </button>
      </form>

      <ErrorBox message={err} />
      <OkBox message={ok} />

      {!rows ? (
        <Spinner />
      ) : rows.length === 0 ? (
        <Empty title={`ยังไม่มี${cur.label}`} hint="เพิ่มรายการแรกจากฟอร์มด้านบน" />
      ) : (
        <ul className="space-y-2">
          {rows.map((r, i) => (
            <li key={r.id} className={`card-plain flex flex-wrap items-center gap-3 ${r.is_active ? '' : 'opacity-60'}`}>
              {tab === 'ranks' && (
                <input
                  type="color"
                  aria-label={`สีของ ${r.name}`}
                  className="h-9 w-12 cursor-pointer border border-line bg-ink p-0.5"
                  value={r.color ?? '#7B2CBF'}
                  onChange={(e) => patch(r.id, { color: e.target.value })}
                />
              )}
              <div className="min-w-[10rem] flex-1">
                {editId === r.id ? (
                  <form
                    className="flex gap-2"
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (editName.trim()) patch(r.id, { name: editName.trim() });
                      setEditId(null);
                    }}
                  >
                    <input autoFocus className="input" value={editName} onChange={(e) => setEditName(e.target.value)} maxLength={80} aria-label="ชื่อใหม่" />
                    <button className="btn-primary btn-sm" type="submit">
                      บันทึก
                    </button>
                  </form>
                ) : (
                  <span className="font-display text-lg font-semibold" style={tab === 'ranks' ? { color: r.color } : undefined}>
                    {r.name}
                  </span>
                )}
                {!r.is_active && <span className="ml-2 font-mono text-xs text-mute">ปิดใช้งาน</span>}
              </div>
              <div className="flex flex-wrap gap-1.5">
                <button className="btn-ghost btn-sm" onClick={() => move(i, -1)} disabled={i === 0} aria-label="เลื่อนขึ้น">
                  ▲
                </button>
                <button className="btn-ghost btn-sm" onClick={() => move(i, 1)} disabled={i === rows.length - 1} aria-label="เลื่อนลง">
                  ▼
                </button>
                <button
                  className="btn-ghost btn-sm"
                  onClick={() => {
                    setEditId(r.id);
                    setEditName(r.name);
                  }}
                >
                  แก้ชื่อ
                </button>
                <button className="btn-ghost btn-sm" onClick={() => patch(r.id, { is_active: !r.is_active })}>
                  {r.is_active ? 'ปิดใช้งาน' : 'เปิดใช้งาน'}
                </button>
                <ConfirmButton label="ลบ" onConfirm={() => remove(r)} />
              </div>
            </li>
          ))}
        </ul>
      )}
      <p className="text-sm text-mute">การลบจะถูกบล็อกถ้ายังมีผู้เล่นใช้รายการนั้นอยู่ หากไม่ต้องการให้เลือกใช้อีก ให้กด "ปิดใช้งาน" แทน (ผู้เล่นที่มีอยู่ยังแสดงตามเดิม และประวัติไม่หาย)</p>
    </div>
  );
}
