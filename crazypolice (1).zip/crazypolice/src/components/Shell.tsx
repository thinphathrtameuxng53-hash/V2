import { useCallback, useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import { supabase } from '../lib/supabase';
import { fmtDate, type Notice } from '../lib/types';
import { ShieldLogo } from './ui';

function NotificationBell() {
  const { user, refreshProfile } = useAuth();
  const [items, setItems] = useState<Notice[]>([]);
  const [open, setOpen] = useState(false);

  const load = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase.from('notifications').select('*').order('created_at', { ascending: false }).limit(30);
    setItems((data ?? []) as Notice[]);
  }, [user?.id]);

  useEffect(() => {
    load();
    if (!user) return;
    const ch = supabase
      .channel('notif-' + user.id)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${user.id}` }, () => {
        load();
        refreshProfile();
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [user?.id]);

  const unread = items.filter((n) => !n.read_at).length;

  async function toggle() {
    const next = !open;
    setOpen(next);
    if (next && unread > 0) {
      await supabase.rpc('mark_notifications_read');
      setTimeout(load, 1500);
    }
  }

  return (
    <div className="relative">
      <button onClick={toggle} className="btn-ghost btn-sm relative" aria-label={`การแจ้งเตือน ${unread} รายการใหม่`} aria-expanded={open}>
        แจ้งเตือน
        {unread > 0 && <span className="rounded-full bg-neon px-1.5 font-mono text-xs font-bold text-ink">{unread}</span>}
      </button>
      {open && (
        <div className="absolute right-0 z-40 mt-2 max-h-96 w-[min(22rem,calc(100vw-2rem))] overflow-y-auto border border-line bg-panel p-2 shadow-2xl">
          {items.length === 0 ? (
            <p className="p-4 text-center text-sm text-mute">ยังไม่มีการแจ้งเตือน</p>
          ) : (
            items.map((n) => (
              <div key={n.id} className="border-b border-line p-3 last:border-0">
                <p className="font-display font-semibold">{n.title}</p>
                {n.body && <p className="mt-0.5 break-words text-sm text-mute">{n.body}</p>}
                <p className="mt-1 font-mono text-xs text-mute/70">{fmtDate(n.created_at)}</p>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

export interface NavItem {
  to: string;
  label: string;
  end?: boolean;
}

export function Shell({ nav, area }: { nav: NavItem[]; area: string }) {
  const { profile, signOut, isAdmin } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen">
      <div className="lightbar" />
      <header className="sticky top-0 z-30 border-b border-line bg-ink/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
          <Link to="/" className="flex items-center gap-2.5">
            <ShieldLogo size={34} />
            <span className="leading-tight">
              <span className="h-display block text-lg">CRAZY POLICE</span>
              <span className="block font-mono text-[10px] uppercase tracking-[0.22em] text-neon">{area}</span>
            </span>
          </Link>
          <div className="flex items-center gap-2">
            {isAdmin && area !== 'ADMIN CONSOLE' && (
              <Link to="/admin" className="btn-purple btn-sm hidden sm:inline-flex">
                หลังบ้านแอดมิน
              </Link>
            )}
            {area === 'ADMIN CONSOLE' && (
              <Link to="/portal" className="btn-ghost btn-sm hidden sm:inline-flex">
                หน้าสมาชิก
              </Link>
            )}
            <NotificationBell />
            <button
              className="btn-ghost btn-sm"
              onClick={async () => {
                await signOut();
                navigate('/');
              }}
            >
              ออกจากระบบ
            </button>
          </div>
        </div>
        <nav className="no-scrollbar mx-auto flex max-w-6xl gap-1 overflow-x-auto px-4 pb-2" aria-label="เมนูหลัก">
          {nav.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.end}
              className={({ isActive }) =>
                `whitespace-nowrap border-b-2 px-3 py-2 font-display text-sm font-semibold transition ${
                  isActive ? 'border-neon text-neon' : 'border-transparent text-mute hover:text-white'
                }`
              }
            >
              {n.label}
            </NavLink>
          ))}
        </nav>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-8">
        <Outlet />
      </main>
      {profile && (
        <footer className="mx-auto max-w-6xl px-4 pb-10 font-mono text-xs text-mute/70">
          ล็อกอินเป็น {profile.discord_name}
        </footer>
      )}
    </div>
  );
}
