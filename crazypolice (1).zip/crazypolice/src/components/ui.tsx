import { useEffect, useRef, useState, type ReactNode } from 'react';
import { signedUrl, validateImage } from '../lib/supabase';
import type { ComplaintStatus, RequestStatus } from '../lib/types';

export function ShieldLogo({ size = 40 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <path d="M32 4l22 8v17c0 14-9.500 24-22 29C19.500 53 10 43 10 29V12z" fill="#7B2CBF" />
      <path d="M32 11l15.500 5.500V29c0 10-6.500 17-15.500 21C23 46 16.500 39 16.500 29V16.500z" fill="#100D18" />
      <path d="M32 19l3.100 6.300 7 1-5 4.900 1.200 6.900L32 34.800l-6.300 3.300 1.200-6.900-5-4.900 7-1z" fill="#39FF88" />
    </svg>
  );
}

export function Spinner({ label = 'กำลังโหลด...' }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-3 py-16 text-mute" role="status">
      <span className="h-2.5 w-2.5 rounded-full bg-neon pulse-dot" />
      <span className="font-mono text-sm tracking-wider">{label}</span>
    </div>
  );
}

export function Empty({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="card-plain border-dashed py-10 text-center">
      <p className="font-display text-lg font-semibold">{title}</p>
      {hint && <p className="mx-auto mt-1 max-w-md text-sm text-mute">{hint}</p>}
    </div>
  );
}

export function ErrorBox({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div role="alert" className="rounded-sm border border-red-500/50 bg-red-500/10 px-3 py-2 text-sm text-red-200">
      {message}
    </div>
  );
}

export function OkBox({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div role="status" className="rounded-sm border border-neon/50 bg-neon/10 px-3 py-2 text-sm text-neon">
      {message}
    </div>
  );
}

export function PageTitle({ eyebrow, title, children }: { eyebrow?: string; title: string; children?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3 rise">
      <div>
        {eyebrow && <p className="eyebrow">{eyebrow}</p>}
        <h1 className="h-display text-2xl sm:text-3xl">{title}</h1>
      </div>
      {children}
    </div>
  );
}

const STATUS_STYLE: Record<string, string> = {
  PENDING: 'border-yellow-400/60 text-yellow-300 bg-yellow-400/10',
  IN_REVIEW: 'border-sky-400/60 text-sky-300 bg-sky-400/10',
  APPROVED: 'border-neon/60 text-neon bg-neon/10',
  RESOLVED: 'border-neon/60 text-neon bg-neon/10',
  REJECTED: 'border-red-400/60 text-red-300 bg-red-400/10',
};

export function StatusChip({ status }: { status: RequestStatus | ComplaintStatus }) {
  return <span className={`chip ${STATUS_STYLE[status] ?? ''}`}>{status.replace('_', ' ')}</span>;
}

export function RankChip({ name, color }: { name?: string | null; color?: string | null }) {
  const c = name ? color || '#7B2CBF' : '#94A3B8';
  return (
    <span
      className="chip"
      style={{ borderColor: c, color: c, background: c + '1A' }}
    >
      {name || 'ประชาชน'}
    </span>
  );
}

export function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 sm:items-center sm:p-4" role="dialog" aria-modal="true" aria-label={title}>
      <div className={`max-h-[92vh] w-full overflow-y-auto border border-line bg-panel p-5 sm:rounded-md ${wide ? 'sm:max-w-3xl' : 'sm:max-w-lg'}`}>
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="h-display text-xl">{title}</h2>
          <button className="btn-ghost btn-sm" onClick={onClose} aria-label="ปิด">
            ปิด
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

/** รูปจาก bucket ส่วนตัว โหลดผ่าน signed URL */
export function SignedImage({ bucket, path, alt, className }: { bucket: 'evidence' | 'guide'; path: string; alt: string; className?: string }) {
  const [url, setUrl] = useState<string | null>(null);
  const [err, setErr] = useState(false);
  useEffect(() => {
    let on = true;
    setUrl(null);
    setErr(false);
    signedUrl(bucket, path)
      .then((u) => on && setUrl(u))
      .catch(() => on && setErr(true));
    return () => {
      on = false;
    };
  }, [bucket, path]);
  if (err) return <p className="text-sm text-red-300">เปิดรูปไม่สำเร็จ</p>;
  if (!url) return <div className="h-40 animate-pulse rounded-sm bg-panel2" />;
  return <img src={url} alt={alt} className={className ?? 'max-h-[70vh] w-full rounded-sm object-contain'} />;
}

/** เลือกรูป + แสดงตัวอย่าง + เปลี่ยน/ลบรูปก่อนส่ง */
export function ImagePicker({
  file,
  onChange,
  label,
  required,
}: {
  file: File | null;
  onChange: (f: File | null) => void;
  label: string;
  required?: boolean;
}) {
  const ref = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (!file) {
      setPreview(null);
      return;
    }
    const u = URL.createObjectURL(file);
    setPreview(u);
    return () => URL.revokeObjectURL(u);
  }, [file]);

  function pick(f: File | undefined) {
    if (!f) return;
    const e = validateImage(f);
    setErr(e);
    if (!e) onChange(f);
    if (ref.current) ref.current.value = '';
  }

  return (
    <div>
      <span className="label">
        {label} {required && <span className="text-neon">*</span>}
      </span>
      <input ref={ref} id="image-picker" type="file" accept="image/png,image/jpeg,image/webp" className="sr-only" onChange={(e) => pick(e.target.files?.[0])} />
      {preview ? (
        <div className="space-y-2">
          <img src={preview} alt="ตัวอย่างรูปที่เลือก" className="max-h-64 w-full rounded-sm border border-line object-contain bg-ink" />
          <div className="flex flex-wrap gap-2">
            <button type="button" className="btn-ghost btn-sm" onClick={() => ref.current?.click()}>
              เปลี่ยนรูป
            </button>
            <button type="button" className="btn-danger btn-sm" onClick={() => onChange(null)}>
              ลบรูป
            </button>
            <span className="self-center font-mono text-xs text-mute">{file?.name}</span>
          </div>
        </div>
      ) : (
        <label
          htmlFor="image-picker"
          className="flex cursor-pointer flex-col items-center justify-center gap-1 rounded-sm border border-dashed border-royal/70 bg-ink px-4 py-8 text-center text-mute hover:border-neon hover:text-white"
        >
          <span className="font-display font-semibold">แตะเพื่อเลือกรูป</span>
          <span className="text-xs">PNG, JPG, JPEG, WEBP ไม่เกิน 5 MB</span>
        </label>
      )}
      {err && <p className="mt-1 text-sm text-red-300">{err}</p>}
    </div>
  );
}

/** ปุ่มยืนยัน 2 ขั้นตอน (กดครั้งแรกเปลี่ยนเป็นปุ่มยืนยัน) */
export function ConfirmButton({ label, confirmLabel = 'ยืนยัน', onConfirm, className = 'btn-danger btn-sm' }: { label: string; confirmLabel?: string; onConfirm: () => void; className?: string }) {
  const [asked, setAsked] = useState(false);
  useEffect(() => {
    if (!asked) return;
    const t = setTimeout(() => setAsked(false), 4000);
    return () => clearTimeout(t);
  }, [asked]);
  return (
    <button
      type="button"
      className={className}
      onClick={() => {
        if (asked) {
          setAsked(false);
          onConfirm();
        } else setAsked(true);
      }}
    >
      {asked ? confirmLabel + '?' : label}
    </button>
  );
}
