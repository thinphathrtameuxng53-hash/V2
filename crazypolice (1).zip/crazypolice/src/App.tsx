import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import type { ReactNode } from 'react';
import { useAuth } from './lib/auth';
import { configured } from './lib/supabase';
import { Shell, type NavItem } from './components/Shell';
import { Spinner } from './components/ui';
import Home from './pages/Home';
import Login from './pages/Login';
import Setup from './pages/Setup';
import Verify from './pages/Verify';
import PortalHome from './pages/portal/PortalHome';
import Rules from './pages/portal/Rules';
import Guide from './pages/portal/Guide';
import Complaints from './pages/portal/Complaints';
import ProfilePage from './pages/portal/ProfilePage';
import AdminHome from './pages/admin/AdminHome';
import AdminMembers from './pages/admin/AdminMembers';
import AdminRanks from './pages/admin/AdminRanks';
import AdminContent from './pages/admin/AdminContent';
import AdminComplaints from './pages/admin/AdminComplaints';

/** ต้องล็อกอิน */
function RequireAuth({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <Spinner />;
  if (!user) return <Navigate to="/login" state={{ from: loc.pathname }} replace />;
  return <>{children}</>;
}

/** ต้องยืนยันตัวตนแล้ว (หรือเป็นแอดมิน) ส่วนนี้เป็นเพียง UX จริง ๆ แล้ว RLS ที่ฐานข้อมูลคือด่านป้องกัน */
function RequireMember({ children }: { children: ReactNode }) {
  const { profile, loading, isAdmin } = useAuth();
  if (loading) return <Spinner />;
  if (!profile) return <Spinner label="กำลังโหลดโปรไฟล์..." />;
  if (!profile.is_verified && !isAdmin) return <Navigate to="/verify" replace />;
  return <>{children}</>;
}

function RequireAdmin({ children, superOnly }: { children: ReactNode; superOnly?: boolean }) {
  const { profile, loading, isAdmin, isSuperAdmin } = useAuth();
  if (loading) return <Spinner />;
  if (!profile) return <Spinner label="กำลังโหลดโปรไฟล์..." />;
  if (!isAdmin || (superOnly && !isSuperAdmin)) return <Navigate to="/portal" replace />;
  return <>{children}</>;
}

const MEMBER_NAV: NavItem[] = [
  { to: '/portal', label: 'หน้าแรก', end: true },
  { to: '/portal/rules', label: 'กฎระเบียบแมพ' },
  { to: '/portal/guide', label: 'วิธีใส่เสื้อเจ้าหน้าที่' },
  { to: '/portal/complaints', label: 'ระบบร้องเรียน' },
  { to: '/portal/profile', label: 'ข้อมูลสมาชิก' },
];

function AdminShell() {
  const { isSuperAdmin } = useAuth();
  const nav: NavItem[] = [
    { to: '/admin', label: 'แดชบอร์ด', end: true },
    { to: '/admin/members', label: 'สมาชิกและยศ' },
    ...(isSuperAdmin ? [{ to: '/admin/ranks', label: 'RANK MANAGEMENT' }] : []),
    { to: '/admin/content', label: 'กฎและคู่มือ' },
    { to: '/admin/complaints', label: 'เรื่องร้องเรียน' },
  ];
  return <Shell nav={nav} area="ADMIN CONSOLE" />;
}

export default function App() {
  if (!configured) return <Setup />;
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route
        path="/verify"
        element={
          <RequireAuth>
            <Verify />
          </RequireAuth>
        }
      />
      <Route
        path="/portal"
        element={
          <RequireAuth>
            <RequireMember>
              <Shell nav={MEMBER_NAV} area="MEMBER PORTAL" />
            </RequireMember>
          </RequireAuth>
        }
      >
        <Route index element={<PortalHome />} />
        <Route path="rules" element={<Rules />} />
        <Route path="guide" element={<Guide />} />
        <Route path="complaints" element={<Complaints />} />
        <Route path="profile" element={<ProfilePage />} />
      </Route>
      <Route
        path="/admin"
        element={
          <RequireAuth>
            <RequireAdmin>
              <AdminShell />
            </RequireAdmin>
          </RequireAuth>
        }
      >
        <Route index element={<AdminHome />} />
        <Route path="members" element={<AdminMembers />} />
        <Route
          path="ranks"
          element={
            <RequireAdmin superOnly>
              <AdminRanks />
            </RequireAdmin>
          }
        />
        <Route path="content" element={<AdminContent />} />
        <Route path="complaints" element={<AdminComplaints />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
