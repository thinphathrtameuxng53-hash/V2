export type Role = 'member' | 'admin' | 'super_admin';

export interface Option {
  id: string;
  name: string;
  color?: string;
  sort_order: number;
  is_active: boolean;
}

export interface Profile {
  id: string;
  discord_id: string | null;
  discord_name: string;
  avatar_url: string | null;
  roblox_name: string | null;
  role: Role;
  is_verified: boolean;
  verified_at: string | null;
  appointed_at: string | null;
  created_at: string;
  rank_id: string | null;
  position_id: string | null;
  department_id: string | null;
  rank: { name: string; color: string } | null;
  position: { name: string } | null;
  department: { name: string } | null;
}

export type RequestStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface VerificationRequest {
  id: string;
  request_no: string;
  user_id: string;
  discord_name: string;
  roblox_name: string;
  claimed_rank: string;
  evidence_path: string | null;
  status: RequestStatus;
  reject_reason: string | null;
  reviewed_by_name: string | null;
  reviewed_at: string | null;
  created_at: string;
}

export interface RankHistory {
  id: string;
  user_id: string;
  action: string;
  old_rank_name: string | null;
  new_rank_name: string | null;
  old_position_name: string | null;
  new_position_name: string | null;
  old_department_name: string | null;
  new_department_name: string | null;
  reason: string;
  changed_by_name: string | null;
  created_at: string;
}

export interface Notice {
  id: string;
  kind: string;
  title: string;
  body: string | null;
  created_at: string;
  read_at: string | null;
}

export interface Rule {
  id: string;
  category: string;
  title: string;
  body: string;
  sort_order: number;
  is_published: boolean;
}

export interface GuideItem {
  id: string;
  title: string;
  body: string;
  image_path: string | null;
  sort_order: number;
}

export type ComplaintStatus = 'PENDING' | 'IN_REVIEW' | 'RESOLVED' | 'REJECTED';

export interface Complaint {
  id: string;
  complaint_no: string;
  user_id: string;
  subject: string;
  accused_name: string;
  details: string;
  evidence_path: string | null;
  status: ComplaintStatus;
  admin_note: string | null;
  handled_by_name: string | null;
  handled_at: string | null;
  created_at: string;
}

export const PROFILE_SELECT =
  '*, rank:ranks(name,color), position:positions(name), department:departments(name)';

export const RULE_CATEGORIES = [
  'กฎทั่วไป',
  'กฎการ Roleplay',
  'กฎการใช้ยานพาหนะ',
  'กฎการปฏิบัติหน้าที่ตำรวจ',
  'กฎการใช้อาวุธภายในเกม',
  'กฎการใช้แชต',
  'ข้อห้ามและบทลงโทษ',
];

export const ACTION_LABEL: Record<string, string> = {
  assign: 'เพิ่มยศ',
  change: 'เปลี่ยนยศ',
  promote: 'เลื่อนยศ',
  demote: 'ลดยศ',
  remove: 'ถอดยศ',
  assignment: 'แก้ตำแหน่ง/หน่วยงาน',
};

export function fmtDate(iso: string | null | undefined): string {
  if (!iso) return '-';
  return new Date(iso).toLocaleString('th-TH', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}
