import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

/** false = ยังไม่ได้ตั้งค่า .env / Environment Variables */
export const configured = Boolean(url && key);

export const supabase = createClient(url || 'http://localhost:54321', key || 'missing-anon-key', {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
});

export const ALLOWED_IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/webp'];
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

export function validateImage(file: File): string | null {
  if (!ALLOWED_IMAGE_TYPES.includes(file.type)) return 'รองรับเฉพาะไฟล์ PNG, JPG, JPEG และ WEBP';
  if (file.size > MAX_IMAGE_BYTES) return 'ไฟล์ใหญ่เกิน 5 MB';
  return null;
}

/** อัปโหลดรูปไปยัง bucket ส่วนตัว คืนค่า path ที่เก็บในฐานข้อมูล */
export async function uploadImage(bucket: 'evidence' | 'guide', folder: string, file: File): Promise<string> {
  const err = validateImage(file);
  if (err) throw new Error(err);
  const ext = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg';
  const path = `${folder}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(bucket).upload(path, file, { contentType: file.type, upsert: false });
  if (error) throw new Error('อัปโหลดรูปไม่สำเร็จ: ' + error.message);
  return path;
}

export async function signedUrl(bucket: 'evidence' | 'guide', path: string): Promise<string> {
  const { data, error } = await supabase.storage.from(bucket).createSignedUrl(path, 3600);
  if (error || !data) throw new Error('เปิดรูปไม่สำเร็จ');
  return data.signedUrl;
}
